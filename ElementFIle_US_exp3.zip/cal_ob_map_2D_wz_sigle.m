function ob_map=cal_ob_map_2D_wz_sigle(nnode,Control_ID,j)
Cnum=length(Control_ID);
map_matrix=zeros(Cnum,2*nnode);

for i=1:Cnum
    if j==1
        map_matrix_id=2*Control_ID(i);
    elseif j==2
        map_matrix_id=2*Control_ID(i)-1;
    end 
    map_matrix(i,map_matrix_id)=1;
end

ob_map=map_matrix;