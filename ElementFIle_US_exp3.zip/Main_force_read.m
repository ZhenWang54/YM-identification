% 读取传感器获得的力学数据
clear;
clc;
close all
Move_amp=2;
filepath_force='D:\onedrive\OneDrive - zju.edu.cn\桌面\第三次超声实验\力学传感器预实验';
force_data = ['force',num2str(Move_amp),'mm','.txt'];
FilePath_force_all = fullfile(filepath_force, force_data);

% data_force=read(FilePath_force_all);
% data_force = importdata(FilePath_force_all, '\t', 8); % 读取txt文件，使用制表符分隔符，跳过第一行
data_force = importdata('force3mm.txt'); % 读取txt文件，使用制表符分隔符，跳过第一行
Force=data_force.data(:,2);
Force_mean=mean(Force(1:100));