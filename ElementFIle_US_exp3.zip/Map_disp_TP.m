% 该函数实现给定被映射点编号node_orign_ID，和贴片底部所有点编号，以及贴片所有点的三维位置，和被映射点的z方向位移node_orign_add
function [nodes_TP_corse_add,nodes_TP_corse,nodes_TP_DISP]=Map_disp_TP(node_orign_ID,node_orign_add,node_all_ID,nodes_TP_corse,coefficient)
    nodes_TP_corse_disp=zeros(size(nodes_TP_corse));
    nodes_TP_corse_disp(:,1:2)=nodes_TP_corse(:,1:2);
    node_rest=setdiff(node_all_ID,node_orign_ID);
    nodes_TP_corse_disp(node_orign_ID,3)=node_orign_add;
    n_rest=size(node_rest,1);
        for i=1:n_rest
            [index, ~] = knnsearch(nodes_TP_corse(node_orign_ID,1:2),nodes_TP_corse(node_rest(i),1:2));
             nodes_TP_corse_disp(node_rest(i),3)=coefficient*nodes_TP_corse_disp(node_orign_ID(index),3);
        end
    nodes_TP_corse_add=nodes_TP_corse+nodes_TP_corse_disp;
%     Plot_scatter3(nodes_TP_corse_add,node_all_ID);
%     Plot_scatter3(nodes_TP_corse,node_all_ID);
%     Plot_scatter3(nodes_TP_corse_disp,node_all_ID);
    nonzero_rows = nodes_TP_corse_disp(:, 3) ~= 0;
    nodes_TP_DISP = nodes_TP_corse_disp(nonzero_rows, :);
%     figure,scatter3(nodes_TP_DISP(:,1),nodes_TP_DISP(:,2),nodes_TP_DISP(:,3))
end