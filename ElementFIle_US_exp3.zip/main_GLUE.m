%% 利用Glue算法求解位移场，并核对
clear;
clc;
close all;
filepath='F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\US_data_20230715\temp_data\exp1';
% filepath='F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\US_data_20230715\temp_data\exp4';
% filepath='F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\US_data_20230715\temp_data\exp6';
%%
Image_before_file=fullfile(filepath,'Resize_before1.bmp');
% Image_after_file=fullfile(filepath,'Resize_after1.bmp');
Image_after_file=fullfile(filepath,'Resize_after2.bmp');
% Image_after_file=fullfile(filepath,'Resize_after3.bmp');
[Axial, Lateral]=FUN_glue(Image_before_file,Image_after_file);
close(1,2)
