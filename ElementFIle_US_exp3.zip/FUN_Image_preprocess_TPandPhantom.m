function [image_cut_before,rect_temp,image_resize_before,image_resize_after]=FUN_Image_preprocess_TPandPhantom(FilePath_before,FilePath_after)
    %% 读取两张原始截屏图片
    % 读取原始图片
    image_initial_before=imread(FilePath_before);
    image_initial_after=imread(FilePath_after);
    % 显示原始图片
    figure,
    imshow(image_initial_before);
%     disp('请在图像窗口中用鼠标框选裁切区域。');
%     rect_temp = getrect; % 获取框选矩形的位置信息
%     disp(rect_temp);
    figure,
    imshow(image_initial_after);
%      rect_temp=[644  167  247  338];
%       rect_temp=[662,170 ,220,315]; % 这个是针对0715_exp6的图像结果
%       rect_temp=[660 170  224  340]; % 这个是针对0715_exp5的图像结果
      rect_temp=[ 658  170 235  360]; % 这个是针对0715_exp2的图像结果
    image_cut_before = imcrop(image_initial_before, rect_temp);
    image_cut_after = imcrop(image_initial_after, rect_temp);
    image_resize_before = imresize(image_cut_before, [1700 508]);
    image_resize_after = imresize(image_cut_after, [1700 508]);
    
end