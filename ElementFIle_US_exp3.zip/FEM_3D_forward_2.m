% 计算假体的3D正向模型,基于力边界约束情况
clear;
clc;
close all;
%% 替换 0715_exp2_
load 0715_exp2_element_back_corse.mat
load 0715_exp2_element_circle_corse.mat
load 0715_exp2_nodes_phantom_corse.mat
load 0715_exp2_element_phantom_new.mat
% load 0715_exp2_DKKG_cylinder.mat
% load 0715_exp2_DKKG_block.mat
load 0715_exp2_FaceNode_up_3D.mat
load 0715_exp2_FaceNode_down_3D.mat
load 0715_exp2_FaceNode_US_3D.mat
% load 0715_exp2_FFG_contact.mat
NU=0.49;
node_corse=nodes_phantom_corse;
%%
tic;
DKKG_block=Compute_DKKG_Tetra(node_corse,element_back_corse,NU);
DKKG_cylinder=Compute_DKKG_Tetra(node_corse,element_circle_corse,NU);
toc;
% figure,tetramesh(element_back_corse,node_corse);
% hold on
% tetramesh(element_circle_corse,node_corse);
% hold off
% save('0715_exp2_DKKG_block.mat','DKKG_block')
% save('0715_exp2_DKKG_cylinder.mat','DKKG_cylinder')
%%
alpha=1;
nnode=size(node_corse,1);
E=1e4;
KKG=E*(alpha*DKKG_cylinder+DKKG_block);
% r = sprank(KKG);
% a=diag(full(KKG));
% disp(r);
Constrain_force=zeros(3*nnode,1);
MB_F=Constrain_force;
% MB_F=FFG_contact;

Constrain_fix=FaceNode_down_3D;
Lk=cal_ob_map(nnode,Constrain_fix);
nKB=size(Lk,1);
KB_U=zeros(nKB,1);

%U2 (Measured Force)
Kall_U2=sparse(3*nnode+nKB,3*nnode+nKB);
Kall_U2(1:3*nnode,1:3*nnode)=KKG;
Kall_U2(3*nnode+1:3*nnode+nKB,1:3*nnode)=Lk;
Kall_U2(1:3*nnode,3*nnode+1:3*nnode+nKB)=Lk';

%Pesudo Force
PFall_U2=[MB_F;KB_U];
%Pesudo Displacement
PUall_U2=Kall_U2\PFall_U2;
U2=PUall_U2(1:3*nnode);
UUG=U2;
A=reshape(UUG,3,length(UUG)/3);
A=A';
UUG_3D_all=UUG;
%%
plotFEMtetra(node_corse,element_back_corse,element_circle_corse,U2)
title(['sidefix_x bottomfix_yz 3D deform, alpha=',num2str(alpha)]);