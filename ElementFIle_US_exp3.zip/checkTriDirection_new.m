function [result,Tnew]=checkTriDirection_new(T,node)
if size(node,2)>3
    node=node(:,2:4);
end

nelem=size(T,1);
result=zeros(nelem,1);
Tnew=T;
for i=1:nelem
    Tn1=T(i,1);
    Tn2=T(i,2);
    Tn3=T(i,3);
    
    v1=node(Tn2,:)-node(Tn1,:);
    v2=node(Tn3,:)-node(Tn2,:);
    v_result=cross(v1,v2);
    result(i)=sign(sum(v_result));
    
    if result(i)<0
        tmp=Tnew(i,1);
        Tnew(i,1)=Tnew(i,2);
        Tnew(i,2)=tmp;
    end
    
end
