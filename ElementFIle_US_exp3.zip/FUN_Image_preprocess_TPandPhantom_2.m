function [image_cut_before,image_resize_before,image_resize_after]=FUN_Image_preprocess_TPandPhantom_2(FilePath_before,FilePath_after,rect_before,rect_after)
    %% 读取两张原始截屏图片
    % 读取原始图片
    image_initial_before=imread(FilePath_before);
    image_initial_after=imread(FilePath_after);
    figure,
    imshow(image_initial_before);
%         手动框选裁切区域
%     disp('请在图像窗口中用鼠标框选裁切区域。');
%     rect_before = getrect; % 获取框选矩形的位置信息
%     disp(rect_before);
    rectangle('Position', rect_before, 'EdgeColor', 'r', 'LineWidth', 0.5);
    figure,
    imshow(image_initial_after);
%         手动框选裁切区域
%     disp('请在图像窗口中用鼠标框选裁切区域。');
%     rect_after = getrect; % 获取框选矩形的位置信息
%     disp(rect_after);
    rectangle('Position', rect_after, 'EdgeColor', 'r', 'LineWidth', 0.5);
%     figure,
%     imshow(image_initial_after);
%      rect_temp=[644  167  247  338];
%     rect_temp = getrect; % 获取框选矩形的位置信息
%     disp(rect_temp);
    image_cut_before = imcrop(image_initial_before, rect_before);
    image_cut_after = imcrop(image_initial_after, rect_after);
    image_resize_before = imresize(image_cut_before, [1700 508]);
    image_resize_after = imresize(image_cut_after, [1700 508]);
end