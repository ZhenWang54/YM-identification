% 手动读取单张截屏并且裁切以及resize
clear;
clc;
close all;
%% exp6
% filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\US_data_20230715\20230714wz\wz20230714\假体和贴片\exp1B\2023-07-14164213\1689324134026/ultrasound.yuv';% 初始
% filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\US_data_20230715\20230714wz\wz20230714\假体和贴片\exp1B\2023-07-14164227\1689324148424/ultrasound.yuv';% 压缩1
% filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\US_data_20230715\20230714wz\wz20230714\假体和贴片\exp1B\2023-07-14164242\1689324162826/ultrasound.yuv';% 压缩2
%% exp4
% filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\US_data_20230715\20230714wz\wz20230714\假体和贴片\exp4\2023-07-14173817\1689327497842/ultrasound.yuv';% 初始
% filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\US_data_20230715\20230714wz\wz20230714\假体和贴片\exp4\2023-07-14173832\1689327512449/ultrasound.yuv';% 压缩1
% filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\US_data_20230715\20230714wz\wz20230714\假体和贴片\exp4\2023-07-14173845\1689327525649/ultrasound.yuv';% 压缩2
%% exp2
% filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp2\US_data_20230715\假体和贴片\exp2\2023-07-14171051\1689325851830/ultrasound.yuv';% 初始
% filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp2\US_data_20230715\假体和贴片\exp2\2023-07-14171106\1689325866625/ultrasound.yuv';% 压缩1
% filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp2\US_data_20230715\假体和贴片\exp2\2023-07-14171132\1689325893135/ultrasound.yuv';% 压缩2
%% exp3
% filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\假体和贴片\exp3\2023-07-14172407\1689326648646/ultrasound.yuv';% 初始
% filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\假体和贴片\exp3\2023-07-14172420\1689326662431/ultrasound.yuv';% 压缩1
% filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\假体和贴片\exp3\2023-07-14172440\1689326682045/ultrasound.yuv';% 压缩2
filepath = 'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\假体和贴片\exp3\2023-07-14172454\1689326695638/ultrasound.yuv';% 压缩2
width = 1280;
height = 1024;

% 读取yuv文件
yuvFileID = fopen(filepath, 'r');
yuvData = fread(yuvFileID, width * height * 2, 'uint8');
fclose(yuvFileID);
j = 1;
for i =1:4:width * height * 2
    yData(j) = yuvData(i);
    uData(j) = yuvData(i+1);
    uData(j+1) = yuvData(i+1);
    
    yData(j+1) = yuvData(i+2);
    vData(j) = yuvData(i+3);
    vData(j+1) = yuvData(i+3);
    j=j+2;
end
yData = reshape(yData, [width, height]);
yData = yData';
%imshow(yData/256);
%%
uData = reshape(uData, [width, height]);
uData = uData';
%imshow(uData/256);
%%
vData = reshape(vData, [width, height]);
vData = vData';
%imshow(vData/256);
%%
rData = yData + 1.13983 * (vData - 128);
gData = yData - 0.39465 * (uData - 128) - 0.58060 * (vData - 128);
bData = yData + 2.03211 * (uData - 128);
rgbData = cat(3, rData, gData, bData);
rgbData = uint8(rgbData);

% 显示rgb图像
figure,
imshow(rgbData);
figure,
flipped_image_ud = flipud(rgbData);
imshow(rgbData);
%保存bmp格式图片
I0 = getimage(gcf);
imageData=I0;

% rect = getrect;%%手动框选。
% disp(rect);
% rect=[356   165   827   238];
% rectTP=[ 638  164 261   72];
% rect_TPandPhantom=rect;
% rect_TPandPhantom=[640 165  233 395]; %exp1
% rect_TPandPhantom=[653  170  233  405];  %exp6
% rect_TPandPhantom=[ 658  170 235  386];  %exp2
% 
% hold on;
% rectangle('Position', rect, 'EdgeColor', 'r', 'LineWidth', 1);
% hold off;
% croppedImage = imcrop(imageData, rect);
% resizedImage = imresize(croppedImage, [1700 508]);
% figure,
% imshow(croppedImage);
% figure,
% imshow(resizedImage);
%% exp2 
% imwrite(I0,'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\temp_data/before1.bmp'); 
% imwrite(croppedImage,'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\temp_data/Cropped_before1.bmp'); 
% imwrite(resizedImage,'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\temp_data/Resize_before1.bmp'); 
% after2 after3 after4
imwrite(I0,'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\temp_data/after3.bmp'); 
% imwrite(croppedImage,'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\temp_data/Cropped_after2.bmp'); 
% imwrite(resizedImage,'F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\temp_data/Resize_after2.bmp'); 
