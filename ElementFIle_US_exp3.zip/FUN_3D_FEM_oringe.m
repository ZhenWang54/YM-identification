function U_3D=FUN_3D_FEM_oringe(alpha,scale,expID)

load(fullfile(['0715_exp',num2str(expID),'_element_back_corse.mat']))
load(fullfile(['0715_exp',num2str(expID),'_element_circle_corse.mat']))
load(fullfile(['0715_exp',num2str(expID),'_element_phantom_new.mat']))% 这个是2D超声切面对应的接触面节点
load(fullfile(['0715_exp',num2str(expID),'_nodes_phantom_corse.mat']))
load(fullfile(['0715_exp',num2str(expID),'_DKKG_cylinder.mat']))
load(fullfile(['0715_exp',num2str(expID),'_DKKG_block.mat']))
load(fullfile(['0715_exp',num2str(expID),'_FaceNode_up_3D.mat']))
load(fullfile(['0715_exp',num2str(expID),'_FaceNode_down_3D.mat']))
load(fullfile(['0715_exp',num2str(expID),'_FaceNode_US_3D.mat']))
load(fullfile(['0715_exp',num2str(expID),'_map_couple.mat']))
NU=0.49;
node_corse=nodes_phantom_corse;
nnode=size(node_corse,1);

Lf=cal_ob_map(nnode,FaceNode_down_3D);% 底部固定边界
nKB_sub1=size(Lf,1);
Lmz=cal_ob_map_3D_wz_sigle(nnode,FaceNode_US_3D,3);% 底部固定边界
Lk_all=[Lf;Lmz];
nKB_all=size(Lk_all,1);
nKB_sub2=size(Lmz,1);

E=1e4;
KKG=E*(alpha*DKKG_cylinder+DKKG_block);
% r = sprank(KKG)
MB_F=zeros(3*nnode,1);%% 力载荷
MB_U=zeros(nKB_sub1,1);%% 固定边界约束
MB_MU=ones(nKB_sub2,1)*scale;%% 移动边界约束

%U2 (Measured Force)
Kall=sparse(3*nnode+nKB_all,3*nnode+nKB_all);
Kall(1:3*nnode,1:3*nnode)=KKG;
Kall(3*nnode+1:3*nnode+nKB_all,1:3*nnode)=Lk_all;
Kall(1:3*nnode,3*nnode+1:3*nnode+nKB_all)=Lk_all';

%Pesudo Force
PFall=[MB_F;MB_U;MB_MU];
%Pesudo Displacement
U3D_temp=Kall\PFall;
U_3D=U3D_temp(1:3*nnode);
% plot
% plotFEMtetra(node_corse,element_back_corse,element_circle_corse,U_3D)
% title(['sidefix_x bottomfix_yz 3D deform, alpha=',num2str(alpha)]);
end