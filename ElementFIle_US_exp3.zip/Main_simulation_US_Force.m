%% 基于力边界条件求取比杨氏模量
clear;
close all;
clc;
%%
load 0715_exp3_FFG_contact.mat %加载三维情况下的假体的外部力
%% 初始化一些参数
std_error_set=[];
t_best_set=[];
iter=0;
alphamax=9;
alphamin=1;
alpha_step=0.25;
alpha2D_set=zeros((alphamax-alphamin)/alpha_step+1,1);
alpha3D_set=zeros((alphamax-alphamin)/alpha_step+1,1);
alpha2D_set_test=zeros((alphamax-alphamin)/alpha_step+1,1);
alpha3D_set_test=zeros((alphamax-alphamin)/alpha_step+1,1);
Fig_N=10; % 第10张图
expID=3;
%%
for alpha_3D=alphamin:alpha_step:alphamax
    iter=iter+1;
    UUG_3D=FUN_3D_FEM_US_force(alpha_3D,FFG_contact,expID);
    save('0715_exp3_UUG_3D.mat ','UUG_3D');
    alpha_2D=Tri_alpha_tool_US_force(1,0.1,200);
    alpha2D_set(iter)=alpha_2D;
    alpha3D_set(iter)=alpha_3D;
end
alphamin_test=alphamin+0.1;
alphamax_test=alphamax+0.1;
iter=0;
for alpha_3D=alphamin_test:alpha_step:alphamax_test
    iter=iter+1;
    UUG_3D=FUN_3D_FEM_US_force(alpha_3D,FFG_contact,expID);
    save('0715_exp3_UUG_3D.mat ','UUG_3D');
    alpha_2D=Tri_alpha_tool_US_force(1,0.1,200);
    alpha2D_set_test(iter)=alpha_2D;
    alpha3D_set_test(iter)=alpha_3D;
end
save('0715_exp3_alpha3D_set.mat','alpha3D_set');
save('0715_exp3_alpha2D_set.mat','alpha2D_set');
save('0715_exp3_alpha3D_set_test.mat','alpha3D_set_test');
save('0715_exp3_alpha2D_set_test.mat','alpha2D_set_test');
%%

load('0715_exp3_alpha3D_set.mat');
load('0715_exp3_alpha2D_set.mat');
load('0715_exp3_alpha3D_set_test.mat');
load('0715_exp3_alpha2D_set_test.mat');
alpha_2D_US=Tri_alpha_tool_simulate_force(1,0.01,500);
alpha_3D_US=Plot_Kriging_US(alpha3D_set,alpha2D_set,alpha3D_set_test,alpha2D_set_test,Fig_N,alpha_2D_US);
disp(['Kriging 预测3D杨氏模量值为：',num2str(alpha_3D_US),' 计算的2D的值为：',num2str(alpha_2D_US),'真实的值为：3.9200']);


