% 批量处理图片数据
ALLfileFolder = fullfile('D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\US\wz620\exp1/');
dirOutput_all = dir(fullfile(ALLfileFolder));
fileNames_all = {dirOutput_all.name};
for i=3:length(fileNames_all)
    A_all=fileNames_all(1,i);
    a_all=cell2mat(A_all);% exp1-B-down-2
    folder_path=fullfile(ALLfileFolder,a_all);
%     disp(folder_path);
    sub_dirOutput_all = dir(fullfile(folder_path));
    sub_fileNames_all = {sub_dirOutput_all.name};
%%
    A_sub_before=sub_fileNames_all(1,3);
    A_sub_before=cell2mat(A_sub_before);
%     disp(A_sub_before);
   folder_add='before';
   FUN_Image_process(folder_path,A_sub_before,folder_add);
%%
    A_sub_after=sub_fileNames_all(1,4);
    A_sub_after=cell2mat(A_sub_after);
%     disp(A_sub_after);
    folder_add='after';
    FUN_Image_process(folder_path,A_sub_after,folder_add)
end