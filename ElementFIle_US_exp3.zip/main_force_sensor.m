clear;
clc;
close all;

%%
load TP4_Element.mat
load TP_4_Node.mat
load TP_4_face_node_up_ID.mat
load TP_4_face_node_down_ID.mat
load DKKG_TP4.mat
node=Node_TP4(:,2:4);
element=ElementTP4(:,2:5);
face_node_fix=face_node_up_ID;
face_node_move=face_node_down_ID;
%%
% E=(38.4+36.6+39.6)/3;
E=37000/1e6; % 这里杨氏模量单位是N/(mm^2)
disp_US=1.75;% 这个应该是从超声图像中获取,对于C1的位移是0.175mm，其真实力数据是-0.0951N。
force_real=-0.4655; % 真实的力传感器值
NU=0.49;
Nnode=size(node,1);
% DKKG_TP4=Compute_DKKG_Tetra(node,element,NU);
% save('DKKG_TP4.mat','DKKG_TP4');
KKG=E*DKKG_TP4;
Lk1=cal_ob_map(Nnode,face_node_fix);
Lk2A=cal_ob_map_3D_wz_sigle(Nnode,face_node_move,3);
Lk_all=[Lk1;Lk2A];
nK1=size(Lk1,1);
nK2A=size(Lk2A,1);
nK_all=size(Lk_all,1);% 被约束的点自由度个数
F=zeros(3*Nnode,1);%% force=0;
U1=zeros(nK1,1);%% 这里是约束指定的点的xyz方向位移为0.
U2=ones(nK2A,1)*disp_US;%% 这里是约束指定的点的z方向位移为scale.

M_left_final=[F;U1;U2];
Kall=sparse(3*Nnode+nK_all,3*Nnode+nK_all);
Kall(1:3*Nnode,1:3*Nnode)=KKG;
Kall(3*Nnode+1:3*Nnode+nK_all,1:3*Nnode)=Lk_all;
Kall(1:3*Nnode,3*Nnode+1:3*Nnode+nK_all)=Lk_all';

M_right=Kall\M_left_final;
U3D=M_right(1:3*Nnode);
P1=M_right(1+3*Nnode:3*Nnode+nK1);
P2=M_right(1+3*Nnode+nK1:3*Nnode+nK1+nK2A);
nP=size(P1,1);
for i=1:nP/3
    PZ(i)=P1(3*i);
end
PZsum=sum(PZ);
% PZsum=0;
disp(['计算获得的z方向合力为',num2str(PZsum)]);
disp(['检测获得的z方向合力为',num2str(force_real)]);


A=reshape(U3D,3,length(U3D)/3);
A=A';
node_new=node+A;
figure(5);tetramesh(element,node_new,'FaceAlpha',0.7,'FaceColor','y','EdgeAlpha',0.7);