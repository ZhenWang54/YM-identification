function A=expand_matrix_2D(B)
   A=repelem(B,2,2).*repmat(eye(2),size(B,1),size(B,2));