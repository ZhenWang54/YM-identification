%% 直接法求取3D的绝对杨氏模量的值
function modulus_3D=FUN_3D_modulus_direct(expID,FFG_contact,UUG_RegionNode_real,alpha)
% STD_error_axial=Tri_find_best_alpha_fix_US_force(alpha)
load(fullfile(['0715_exp',num2str(expID),'_element_back_corse.mat']))
load(fullfile(['0715_exp',num2str(expID),'_element_circle_corse.mat']))
load(fullfile(['0715_exp',num2str(expID),'_nodes_phantom_corse.mat']))
load(fullfile(['0715_exp',num2str(expID),'_element_phantom_new.mat']))
load(fullfile(['0715_exp',num2str(expID),'_DKKG_cylinder.mat']))
load(fullfile(['0715_exp',num2str(expID),'_DKKG_block.mat']))
load(fullfile(['0715_exp',num2str(expID),'_FaceNode_up_3D.mat']))
load(fullfile(['0715_exp',num2str(expID),'_FaceNode_down_3D.mat']))
load(fullfile(['0715_exp',num2str(expID),'_FaceNode_US_3D.mat']))
% load(fullfile(['0715_exp',num2str(expID),'_FFG_contact.mat']))
load(fullfile(['0715_exp',num2str(expID),'_RegionNode_US.mat']))
node_corse=nodes_phantom_corse;
nnode=size(node_corse,1);
KKG=(alpha*DKKG_cylinder+DKKG_block);
MB_F=FFG_contact;

Constrain_fix=FaceNode_down_3D;
Lk=cal_ob_map(nnode,Constrain_fix);
nKB=size(Lk,1);
KB_U=zeros(nKB,1);
Kall_U2=sparse(3*nnode+nKB,3*nnode+nKB);
Kall_U2(1:3*nnode,1:3*nnode)=KKG;
Kall_U2(3*nnode+1:3*nnode+nKB,1:3*nnode)=Lk;
Kall_U2(1:3*nnode,3*nnode+1:3*nnode+nKB)=Lk';
%Pesudo Displacement
iKall=Kall_U2\eye(size(Kall_U2,1));
iKall_11=iKall(1:3*nnode,1:3*nnode);
iKall_12=iKall(1:3*nnode,3*nnode+1:3*nnode+nKB);
%
UUG_target_3D=zeros(nnode,3);
UUG_target_3D(RegionNode_US,3)=UUG_RegionNode_real;
UUG_target_3D=UUG_target_3D';
UUG_target_3D=UUG_target_3D(:);
nodes_phantom=1:1:size(nodes_phantom_corse,1);nodes_phantom=nodes_phantom';
weight_add=ismember(nodes_phantom,RegionNode_US);
weight_matrix=diag(weight_add);
weight_matrix=expand_matrix_3D_z(weight_matrix);
A=weight_matrix*iKall_11*MB_F;
b=weight_matrix*(UUG_target_3D-iKall_12*KB_U);
modulus_3D=1/((A'*A)\(A'*b)); %单位是N/mm^2
modulus_3D=modulus_3D*1000000/1000;% 单位是Kpa
end