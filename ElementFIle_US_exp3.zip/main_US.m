% 一键运行整体所有流程；需要after_Xmm.bmp 和 before_Xmm.bmp 的图片作为输入，其中X代表的是按压距离
% 需要提前计算好对应模型的alpha3D_set和alpha2D_set
clear
clc
close all
load alpha3D_set.mat
load alpha2D_set.mat
load alpha3D_set_test.mat
load alpha2D_set_test.mat
load node_corse.mat %加载整体节点对应的初始坐标
load RegionNode_US.mat % 被选择去计算位移场的节点
scale_X=11;% 表示截屏图像X像素尺寸和实际尺寸的比例
scale_Y=17;% 表示截屏图像Y像素尺寸和实际尺寸的比例
T_tran=[15,40];%表示US处理位移场丢掉的边框尺寸，这个和GLUE算法相关
Move_amp=input('请输入按压位移的值(虽然这里是手动输入的，但实际应该根据超声图像进行计算)：');
save('Move_amp.mat','Move_amp')
Fig_N=10;
%% 读取两张原始截屏图片，并输出裁切、resize后的图片
filepath_input='D:\onedrive\OneDrive - zju.edu.cn\桌面\临时转存文件\TP_and_phantom';
filepath_output='D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\Image';
filepath_output_TP='D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\Image_TP_phantom';
[TP_image_cut_before,TP_rect,TP_Image_before_file,TP_Image_after_file]=FUN_TP_Image_preprocess(Move_amp,filepath_input,filepath_output_TP);
[image_cut_before,rect,Image_before_file,Image_after_file]=FUN_Image_preprocess(Move_amp,filepath_input,filepath_output);
imtest1=imread(Image_before_file);
figure(20),
imshow(imtest1);
imtest2=imread(Image_after_file);
figure(21),
imshow(imtest2);
%% GLUE计算
[Axial, Lateral]=FUN_glue(Image_before_file,Image_after_file);
figure, imagesc(Axial), colorbar, title('axial displacement'), colormap(hot);
figure, imagesc(Lateral), colorbar, title('lateral displacement'), colormap(hot);
%%
P_center_cut=FUN_get_center_node(image_cut_before);% 选取裁切图像中圆心的位置
scale_reviseX=rect(3)/508;%表示裁切的图像到US变换的横向变换比例
scale_reviseY=rect(4)/1700;%表示裁切的图像到US变换的纵向变换比例
scale_revise=[scale_reviseX,scale_reviseY];
scale_US_FEM=[scale_reviseX/scale_X,scale_reviseY/scale_Y];% 这里表示超声位移场中的像素坐标与实际mm坐标之间的尺度变换
P_center_US=P_center_cut./scale_revise;% 超声初始图片里，圆心的位置
P_center_Axial=P_center_US+T_tran;% 超声位移场Axial中，圆心的位置（有一个裁切）
%% 是把FEM的尺寸变换到Axial里面，求取对应的位移场，然后再变换回FME。
P_FEM_center=[18,7.5];% 有限元下的中心点位置
P_center_FEM_to_Axial=P_FEM_center./scale_US_FEM;% Axial下的圆心位置
T_axial_FEM=P_center_Axial-P_center_FEM_to_Axial;

%% 计算有限元网格结点对应的位移场
[n_ROI,~]=size(RegionNode_US);
P_FEM_to_Axial=zeros(n_ROI,2);
Position_FEM(:,1)=node_corse(RegionNode_US,1);
Position_FEM(:,2)=node_corse(RegionNode_US,3);
Position_FEM_rot(:,1)=Position_FEM(:,1);
Position_FEM_rot(:,2)=32-Position_FEM(:,2);
displacements=zeros(n_ROI,2);
for i=1:n_ROI
    P_FEM_to_Axial(i,:)=Position_FEM_rot(i,:)./scale_US_FEM+T_axial_FEM;   % 有限元结点对应的axial下的像素坐标
    P_FEM_to_Axial(i,:)=round(P_FEM_to_Axial(i,:)); % 取整后的像素坐标
    y = P_FEM_to_Axial(i, 1);% 获得目标点在超声图像坐标系下的横纵坐标值
    x = P_FEM_to_Axial(i, 2);    
    displacementX = Lateral(x,y)*scale_US_FEM(1);
    displacementY = -Axial(x,y)*scale_US_FEM(2);
    displacements(i, :) = [displacementX, displacementY];%displacements是一个Nx2的矩阵，包含位置矩阵中每个点对应的最接近图像点的横向位移和纵向位移
    % 注意，Axial里面的位移场方向是相对于Axial坐标系的，所以Axial的方向应该变换一下
end
displacements2=displacements';
displacements_new=displacements2(:);%displacements是一个2N的一维向量，对应于2D截面的位移场；
U2_real_Local=displacements_new;
U2_real_Local_temp=U2_real_Local;
save('U2_real_Local.mat','U2_real_Local');
save('U2_real_Local_temp.mat','U2_real_Local_temp');
%% 
figure, imagesc(Axial), colorbar, title('axial displacement'), colormap(hot);
hold on
scatter(P_FEM_to_Axial(:,1),P_FEM_to_Axial(:,2),'k'); % 显示有限元的节点
P_center_Axial=P_center_Axial';
P_center_FEM_to_Axial=P_center_FEM_to_Axial';
scatter(P_center_FEM_to_Axial(1),P_center_FEM_to_Axial(2),'+b');% +号表示有限元的中心点（没平移变换之前的）
% scatter(-T_axial_FEM(1),T_axial_FEM(2),'+b');% +号表示有限元的中心点（没平移变换之前的）
scatter(P_center_Axial(1),P_center_Axial( 2),'*b'); % 手动选择的超声图像中的点
hold off
%%
figure(20),
hold on
scatter(P_FEM_to_Axial(:,1)-15,P_FEM_to_Axial(:,2)-40,'r'); % 显示有限元的节点
hold off
%%
alpha_2D_US=Tri_alpha_tool_US_disp(1,0.1,200);
alpha_3D_US=Plot_Kriging_US(alpha3D_set,alpha2D_set,alpha3D_set_test,alpha2D_set_test,Fig_N,alpha_2D_US);
disp(['计算的3D杨氏模量=',num2str(alpha_3D_US),'计算的2D杨氏模量=', num2str(alpha_2D_US)]);