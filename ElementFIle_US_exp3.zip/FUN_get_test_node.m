function P_test=FUN_get_test_node(image_cut_before)
    imshow(image_cut_before);
    disp('请在图像窗口中单击所需像素点。按Enter键完成选择。');
    [x, y] = ginput();  % 获取手动选择的像素点坐标
    % 显示选择的像素点
    hold on;
    scatter(x, y, 'ro', 'filled');
    hold off;
    % 确认选择
    numPoints = length(x);
    keepIndices = false(1, numPoints);  % 用于存储要保留的像素点索引的逻辑数组
    for i = 1:numPoints
        % 显示当前选择的像素点
        hold on;
        scatter(x(i), y(i), 'go', 'filled');
        hold off;
        % 确认当前像素点是否要保留
        answer = input('要保留当前像素点吗？（y/n）: ', 's');
        if strcmpi(answer, 'y')
            keepIndices(i) = true;  % 标记要保留的像素点
        end 
        % 清除上次显示的像素点
        hold on;
        scatter(x(i), y(i), 'ro', 'filled');
        hold off;
    end
    % 提取保留的像素点数据
    keepIndices=keepIndices';
    x_nodes=x(keepIndices);
    y_nodes=y(keepIndices);
    x_nodes=x_nodes';
    y_nodes=y_nodes';
    P_test=[x_nodes;y_nodes];
end