function plotFEMtetra(node,element_block,element_cylinder,UUG)
A=reshape(UUG,3,length(UUG)/3);
A=A';
nodenew=node+A;

figure;
tetramesh(element_block,nodenew,'FaceAlpha',0.7,'FaceColor','y','EdgeAlpha',0.7);
hold on
tetramesh(element_cylinder,nodenew,'FaceAlpha',0.7,'FaceColor','b','EdgeAlpha',0.7);

xlabel('x');
ylabel('y');
zlabel('z');


hold off