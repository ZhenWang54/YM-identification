function Plot_2D_FEM(node_deformed,Face3_Tri_Res,Face3_Tri_circle,scale,alpha)
trimesh(Face3_Tri_Res,node_deformed(:,1),node_deformed(:,2),node_deformed(:,3),'FaceColor',[143 163 222]/256,'EdgeColor','k')
hold on
trimesh(Face3_Tri_circle,node_deformed(:,1),node_deformed(:,2),node_deformed(:,3),'FaceColor',[143 163 222]/256,'EdgeColor','k')
xlabel('x');
ylabel('y');
zlabel('z');
title(['仿真变形图，压缩位移= ' num2str(scale) '比值alpha=' num2str(alpha)]);
axis equal
view(30,45)
end