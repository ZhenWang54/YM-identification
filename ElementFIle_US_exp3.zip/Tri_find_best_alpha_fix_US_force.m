function STD_error_axial=Tri_find_best_alpha_fix_US_force(alpha)
% 以等效施加力作为超声界条件的情况
%% the 2D FEM model 
% alpha=1;
load('0715_exp3_FaceNode_2D.mat');
load('0715_exp3_nodes_phantom_corse.mat')
load('0715_exp3_Face_Tri.mat');
load('0715_exp3_Face_tri_circle.mat');
load('0715_exp3_Face_tri_rest.mat');

load('0715_exp3_DKKG_Face2D_Res.mat');
load('0715_exp3_DKKG_Face2D_circle.mat');
load('0715_exp3_Line_node_down.mat');
load('0715_exp3_Line_node_up.mat');
load 0715_exp3_U2_TP_Disp.mat %% 第偶数个是z方向的位移
load('0715_exp3_RegionNode_US.mat');
load('0715_exp3_UUG_3D.mat ');
% load 0715_exp3_Forcedisp_Phantom_2D.mat
% load('U2_real_Local.mat');
% load('U2_real_Local_temp.mat');

load 0715_exp3_Force_Phantom_2D.mat %% Main_contact_force_generation.m line50生成

Force=Force_Phantom_2D;
node_corse=nodes_phantom_corse;


nnode=size(node_corse,1);
UUG_3D_all=UUG_3D;%
G2L_map=cal_ob_map(nnode,RegionNode_US); % 这里是以选中的目标区域求取局部位移场
U2_real=G2L_map*UUG_3D_all;
U2_real_matrix=reshape(U2_real,3,length(U2_real)/3);
U2_real_matrix=U2_real_matrix';
U2_real_Local_matrix=[U2_real_matrix(:,1),U2_real_matrix(:,3)];
U2_real_Local=U2_real_Local_matrix';
U2_real_Local=U2_real_Local(:);
UUG_target=U2_real_Local;
%%
E=15000/1e6; 
nnode=size(node_corse,1);
nnode_Face=length(FaceNode_2D);
KKG=E*(alpha*DKKG_Face2D_circle+DKKG_Face2D_Res);

Constrain_fix_map=mapsetID(nnode,FaceNode_2D,Line_node_down);% 2D有限元底边上的点
Lk=cal_ob_map_2D(nnode_Face,Constrain_fix_map);
nKB=size(Lk,1);
KB_U=zeros(nKB,1);% 固定位移约束

Kall_U2=sparse(2*nnode_Face+nKB,2*nnode_Face+nKB);
Kall_U2(1:2*nnode_Face,1:2*nnode_Face)=KKG;
Kall_U2(2*nnode_Face+1:2*nnode_Face+nKB,1:2*nnode_Face)=Lk;
Kall_U2(1:2*nnode_Face,2*nnode_Face+1:2*nnode_Face+nKB)=Lk';

%Pesudo Force
MB_F=Force;
% PFall_U2=[MB_F;KB_U];

%% 基于力约束求解t，再求解对应的位移场
% target 2D displacement for all the 2D nodes,但是其实只有目标区域的点被赋值了。
UUG_target_2D=zeros(nnode_Face,2);
nRegionNode=size(RegionNode_US,1);
UUG_target_reshap=reshape(UUG_target,2,nRegionNode)';
logicalIndices=ismember(FaceNode_2D,RegionNode_US);
indices = find(logicalIndices);
UUG_target_2D(indices,:)=UUG_target_reshap;
UUG_target_2D=UUG_target_2D';
UUG_target_2D=UUG_target_2D(:);
%Pesudo Displacement
iKall=Kall_U2\eye(size(Kall_U2,1));
iKall_11=iKall(1:2*nnode_Face,1:2*nnode_Face);
iKall_12=iKall(1:2*nnode_Face,2*nnode_Face+1:2*nnode_Face+nKB);
weight_add=ismember(FaceNode_2D,RegionNode_US);
weight_matrix=diag(weight_add);
weight_matrix=expand_matrix_2D(weight_matrix);
A=weight_matrix*iKall_11*MB_F;
b=weight_matrix*(UUG_target_2D-iKall_12*KB_U);
best_t_LS=1/((A'*A)\(A'*b));
U2_Force=(1/best_t_LS)*iKall_11*MB_F+iKall_12*KB_U;
%%
U2_calculate=U2_Force;
%% 将2D的位移场提取出目标区域点的位移场
logicalIndices=ismember(FaceNode_2D,RegionNode_US);
indices = find(logicalIndices);
% indices = logicalIndices;
n_indices=size(indices,1);
U2new=reshape(U2_calculate,2,length(U2_calculate)/2);
U2new=U2new';
U2_target=U2new(indices,:);
U2_target=U2_target';
U2_target=U2_target(:);
%%  error
UUG_target_axial=zeros((size(UUG_target,1))/2,1);
U2_target_axial=zeros((size(UUG_target,1))/2,1);
for i=1:size(UUG_target)/2
    UUG_target_axial(i)=UUG_target(2*i);
    U2_target_axial(i)=U2_target(2*i);
end
UUG_target_axial=UUG_target_axial';
U2_target_axial=U2_target_axial';
STD_error_axial = sqrt(mean((UUG_target_axial - U2_target_axial).^2));
end