function [x,fval,exitflag,output,lambda,grad,hessian] = Tri_alpha_tool_US_force(x0,lb,ub)
%% This is an auto generated MATLAB file from Optimization Tool.

%% Start with the default options
options = optimoptions('fmincon');
%% Modify options setting
options = optimoptions(options,'Display', 'off');
[x,fval,exitflag,output,lambda,grad,hessian] = ...
fmincon(@Tri_find_best_alpha_fix_US_force,x0,[],[],[],[],lb,ub,[],options);
