%% the 2D FEM model 
clc;
clear;
close all;

% 0715_exp3
load 0715_exp3_nodes_phantom_corse.mat
% load 0715_exp3_node_corse.mat
load 0715_exp3_Face_Tri.mat
load 0715_exp3_Face_tri_circle.mat
load 0715_exp3_Face_tri_rest.mat
load 0715_exp3_FaceNode_2D.mat
% load 0715_exp3_DKKG_Face2D_Res.mat
% load 0715_exp3_DKKG_Face2D_circle.mat
load 0715_exp3_Line_node_down.mat
load 0715_exp3_Line_node_up.mat
%%
scale=1;%这里指的是被压缩的位移大小
alpha=1;%待输入的参数
t=1;
NU=0.49;
p=2;
E=1e4;
node_corse=nodes_phantom_corse;
nnode=size(node_corse,1);
nnode_Face=length(FaceNode_2D);

[result,Face_tri_circle1]=checkTriDirection_new(Face_tri_circle,node_corse);
[result1,Face_tri_rest1]=checkTriDirection_new(Face_tri_rest,node_corse);

testFace_tri_circle1=Face_tri_circle1-Face_tri_circle;
testFace_tri_rest1=Face_tri_rest1-Face_tri_rest;
DKKG_Face2D_Res=Compute_DKKG_Tri_xz(node_corse,FaceNode_2D,Face_tri_rest,NU,p);
DKKG_Face2D_circle=Compute_DKKG_Tri_xz(node_corse,FaceNode_2D,Face_tri_circle,NU,p);


scatter3(node_corse(FaceNode_2D,1),node_corse(FaceNode_2D,2),node_corse(FaceNode_2D,3))
save('0715_exp3_DKKG_Face2D_Res.mat','DKKG_Face2D_Res')
save('0715_exp3_DKKG_Face2D_circle.mat','DKKG_Face2D_circle')
KKG=E*(alpha*DKKG_Face2D_circle+DKKG_Face2D_Res);
sss=diag(full(KKG));
Constrain_fix_map=mapsetID(nnode,FaceNode_2D,Line_node_up);% 2D有限元底边上的点
Constrain_move_map=mapsetID(nnode,FaceNode_2D,Line_node_down);% 2D有限元底边上的点
Lf=cal_ob_map_2D(nnode_Face,Constrain_fix_map);
Lm1=cal_ob_map_2D_wz_sigle(nnode_Face,Constrain_move_map,2);% 这里代表控制y方向位移
Lm2=cal_ob_map_2D_wz_sigle(nnode_Face,Constrain_move_map,1);% 这里代表控制z方向位移

Lf_all=[Lf;Lm1];
Lm_all=Lm2;% 这里指的是施加的强制位移，沿着z方向的

Lk_all=[Lf_all;Lm_all];
nKB_all=size(Lk_all,1);
MB_F=zeros(2*nnode_Face,1);%% force=0;
nf=size(Lf_all,1);
nm=size(Lm_all,1);
U1=zeros(nf,1);%% 这里是约束指定的点的xyz方向位移为0.
U2=ones(nm,1)*scale;%% 这里是约束指定的点的z方向位移为scale.
KB_U=[U1;U2];
M_left=[MB_F;KB_U];

Kall_U2=sparse(2*nnode_Face+nKB_all,2*nnode_Face+nKB_all);
Kall_U2(1:2*nnode_Face,1:2*nnode_Face)=KKG;
Kall_U2(2*nnode_Face+1:2*nnode_Face+nKB_all,1:2*nnode_Face)=Lk_all;
Kall_U2(1:2*nnode_Face,2*nnode_Face+1:2*nnode_Face+nKB_all)=Lk_all';

%% 直接求逆
M_right=Kall_U2\M_left;
U_2D=M_right(1:2*nnode_Face);
%% 将2D计算的位移场转换到3D空间
U2new=reshape(U_2D,2,length(U_2D)/2);
U2new=U2new';
% U2new_final=[U2new(:,1),zeros(size(U2new(:,1))),U2new(:,2)];
U2new_final=[U2new(:,1),zeros(size(U2new(:,1))),U2new(:,2)];
U2_expand=U2new_final';
U2_expand=U2_expand(:);
U2_global=zeros(nnode,3);
U2_global(FaceNode_2D,:)=U2new_final;
node_new=node_corse+U2_global;
%% plot
figure(7)
Plot_2D_FEM(node_new,Face_tri_rest,Face_tri_circle,scale,alpha)
xlabel('x');
ylabel('y');
zlabel('z');
hold on 
title(['仿真变形图，压缩位移= ' num2str(scale) '比值alpha=' num2str(alpha)]);
view(30,45)
axis equal
figure(8)
Plot_2D_FEM(node_corse,Face_tri_rest,Face_tri_circle,scale,alpha)
xlabel('x');
ylabel('y');
zlabel('z');
hold on 
title(['仿真变形图，压缩位移= ' num2str(0) '比值alpha=' num2str(alpha)]);
view(30,45)
axis equal