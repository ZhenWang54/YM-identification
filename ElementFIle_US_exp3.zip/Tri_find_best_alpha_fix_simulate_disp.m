function STD_error_axial=Tri_find_best_alpha_fix_simulate_disp(alpha)
% 以强制位移作为超声界条件的情况
% alpha=3.887;
%% the 2D FEM model 
load('0715_exp3_FaceNode_2D.mat');
load('0715_exp3_nodes_phantom_corse.mat')
load('0715_exp3_Face_Tri.mat');
load('0715_exp3_Face_tri_circle.mat');
load('0715_exp3_Face_tri_rest.mat');
load('0715_exp3_FaceNode_2D.mat');
load('0715_exp3_DKKG_Face2D_Res.mat');
load('0715_exp3_DKKG_Face2D_circle.mat');
load('0715_exp3_Line_node_down.mat');
load('0715_exp3_Line_node_up.mat');
load 0715_exp3_U2_TP_Disp.mat %% 第偶数个是z方向的位移
load('0715_exp3_RegionNode_US.mat');
load('0715_exp3_Forcedisp_Phantom_2D.mat');
load('0715_exp3_U2_real_Local.mat');
load('0715_exp3_A_UUG_3D.mat ');
symbol=-1;
node_corse=nodes_phantom_corse;
nnode=size(node_corse,1);
UUG_target=symbol*U2_real_Local;
Forced_disp=symbol*Forcedisp_Phantom_2D;
%%
% UUG_3D_all=UUG_3D;%
% % G2L_map=cal_ob_map(nnode,FaceNode_2D);
% G2L_map=cal_ob_map(nnode,RegionNode_US); % 这里是以选中的目标区域求取局部位移场
% U2_real=G2L_map*UUG_3D_all;
% U2_real_matrix=reshape(U2_real,3,length(U2_real)/3);
% U2_real_matrix=U2_real_matrix';
% U2_real_Local_matrix=[U2_real_matrix(:,2),U2_real_matrix(:,3)];
% U2_real_Local=U2_real_Local_matrix';
% U2_real_Local=U2_real_Local(:);
% UUG_target=U2_real_Local;
%%
E=1e4;
nnode_Face=length(FaceNode_2D);
KKG=E*(alpha*DKKG_Face2D_circle+DKKG_Face2D_Res);
Constrain_fix_map=mapsetID(nnode,FaceNode_2D,Line_node_down);% 2D有限元底边上的点
Constrain_move_map=mapsetID(nnode,FaceNode_2D,Line_node_up);% 2D有限元超声接触边上的点
Lf=cal_ob_map_2D(nnode_Face,Constrain_fix_map);
% Lm1=cal_ob_map_2D_wz_sigle(nnode_Face,Constrain_move_map,2);% 这里代表控制y方向位移
Lm2=cal_ob_map_2D_wz_sigle(nnode_Face,Constrain_move_map,1);% 这里代表控制z方向位移

Lf_all=Lf;
% Lf_all=[Lf;Lm1];
Lm_all=Lm2;% 这里指的是施加的强制位移，沿着z方向的

Lk_all=[Lf_all;Lm_all];
nKB_all=size(Lk_all,1);
MB_F=zeros(2*nnode_Face,1);%% force=0;
nf=size(Lf_all,1);
% nm=size(Lm_all,1);
U1=zeros(nf,1);%% 这里是约束指定的点的xyz方向位移为0.
% U2=ones(nm,1)*scale;%% 这里是约束指定的点的z方向位移为scale.
U2=Forced_disp;%% 这里是约束指定的点的z方向位移，位移通过超声位移图像计算获得。
KB_U=[U1;U2];
M_left=[MB_F;KB_U];
Kall_U2=sparse(2*nnode_Face+nKB_all,2*nnode_Face+nKB_all);
Kall_U2(1:2*nnode_Face,1:2*nnode_Face)=KKG;
Kall_U2(2*nnode_Face+1:2*nnode_Face+nKB_all,1:2*nnode_Face)=Lk_all;
Kall_U2(1:2*nnode_Face,2*nnode_Face+1:2*nnode_Face+nKB_all)=Lk_all';
%% 直接求逆
M_right=Kall_U2\M_left;
U2Disp=M_right(1:2*nnode_Face);
%% 将2D的位移场提取出目标区域点的位移场
logicalIndices=ismember(FaceNode_2D,RegionNode_US);
indices = find(logicalIndices);
% indices = logicalIndices;
n_indices=size(indices,1);
U2new=reshape(U2Disp,2,length(U2Disp)/2);
U2new=U2new';
U2_Res=U2new(indices,:);
U2_Res=U2_Res';
U2_Res=U2_Res(:);
%%  error
for i=1:size(UUG_target)/2
    UUG_target_axial(i)=UUG_target(2*i);
    U2_Res_axial(i)=U2_Res(2*i);
    UUG_target_lateral(i)=UUG_target(2*i-1);
    U2_Res_lateral(i)=U2_Res(2*i-1);
end
UUG_target_axial=UUG_target_axial';
U2_Res_axial=U2_Res_axial';
UUG_target_lateral=UUG_target_lateral';
U2_Res_lateral=U2_Res_lateral';

STD_error = sqrt(2*mean((UUG_target - U2_Res).^2));
STD_error_axial = sqrt(mean((UUG_target_axial - U2_Res_axial).^2));
STD_error_lateral = sqrt(mean((UUG_target_lateral - U2_Res_lateral).^2));
end