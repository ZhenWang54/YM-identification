function [Axial, Lateral]=FUN_glue(Image_before_file,Image_after_file)
    
    imtest=imread(Image_before_file);
    grayImage = rgb2gray(imtest);
    Im1 = im2double(grayImage);
    imtest=imread(Image_after_file);
    grayImage = rgb2gray(imtest);
    Im2 = im2double(grayImage);

    %%
    % ------------------------------------------------------- %
    % ------------- set See_B_mode to see B-mode ------------ %
    % ------------------------------------------------------- %
    See_B_mode = 1;
    if See_B_mode
        BMODE1 = log(abs(hilbert(Im1))+.01);
        figure,  imagesc(BMODE1);colormap(gray), colorbar
        BMODE2 = log(abs(hilbert(Im2))+.01);
        figure, imagesc(BMODE2);colormap(gray), colorbar
    end

    See_B_mode = 1;
    if See_B_mode
        BMODE1 = log(abs((Im1))+.01);
        figure,  imagesc(BMODE1);colormap(gray), colorbar
        BMODE2 = log(abs((Im2))+.01);
        figure, imagesc(BMODE2);colormap(gray), colorbar
    end

    % ------------------------------------------------------- %
    % ---------- initial displacements using 2D DPAM -------- %
    % ------------------------------------------------------- %
    IRF = [-100 0]; % Maximum allowed disparity in axial D
    IA = [-4 4]; % Maximum allowed disparity in lateral D
    midA = 50;
    alfa = 5; %axial regularization
    beta = 10; %lateral regularization
    gamma = 0.005; %lateral regularization 
    T = .2; % threshold for IRLS
    xx = 1; % to compensate for attenuation
    alfa_DP = 0.2; % DP regularization weight
    [ax0, lat0, ~] = RCF_AM2D(Im1, Im2, IRF, IA, midA, alfa_DP, alfa, beta, gamma, T, xx);
    % the disp. of the first 40 and last 40 samples is not calculated in AM2D: 
    % the disp. of the first 10 and last 10 A-lines is not calculated in AM2D:
    % 原来的代码是把图像的竖直方向上下各减去了40个像素1700-80=1620，左右也各减去了15个像素。
    ax0 = ax0(41:end-40, 16:end-15);
    lat0 = lat0(41:end-40, 16:end-15);
    Im1 = Im1(41:end-40, 16:end-15);
    Im2 = Im2(41:end-40, 16:end-15);
    % 我觉得不能减去这些
    % ------------------------------------------------------- %
    % ---------- accurate displacements using GLUE ---------- %
    % ------------------------------------------------------- %
    alfa1 = 5 ; % regularization coefficients
    alfa2 = 1 ;
    beta1 = 5 ; 
    beta2 = 1 ;
    [Axial, Lateral] = GLUE (ax0, lat0, Im1, Im2, alfa1, alfa2, beta1, beta2);
%     figure, imagesc(Axial), colorbar, title('axial displacement'), colormap(hot);
%     figure, imagesc(Lateral), colorbar, title('lateral displacement'), colormap(hot);
end