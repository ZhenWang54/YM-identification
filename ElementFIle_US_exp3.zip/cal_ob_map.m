function ob_map=cal_ob_map(nnode,Control_ID)
Cnum=length(Control_ID);
map_matrix=zeros(Cnum,nnode);


for i=1:Cnum
    map_matrix(i,Control_ID(i))=1;
end

ob_map=expand_matrix_3D(map_matrix);