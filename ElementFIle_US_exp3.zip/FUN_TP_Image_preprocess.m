function [image_cut_before,rect_temp,Image_before_file,Image_after_file]=FUN_TP_Image_preprocess(Move_amp,filepath_input,filepath_output)
    N=Move_amp;
    image_before = ['before_',num2str(Move_amp),'mm','.bmp'];
    FilePath_before = fullfile(filepath_input, image_before);
    image_after = ['after_',num2str(Move_amp),'mm','.bmp'];
    FilePath_after = fullfile(filepath_input, image_after);
    %% 读取两张原始截屏图片
    % 读取原始图片
    image_initial_before=imread(FilePath_before);
    image_initial_after=imread(FilePath_after);
    % 显示原始图片
    figure,
    imshow(image_initial_before);
    title(['这张图片是before_',num2str(Move_amp),'mm'])
    figure,
    imshow(image_initial_after);
    title(['这张图片是after_',num2str(Move_amp),'mm'])
    % 手动框选裁切区域
%     disp('请在图像窗口中用鼠标框选裁切区域。');
    rect_temp = getrect; % 获取框选矩形的位置信息
    disp(rect_temp);
%     rect_temp= [641   166   256    68];
%     rect_temp = getrect; % 获取框选矩形的位置信息
    disp(rect_temp);
    image_cut_before = imcrop(image_initial_before, rect_temp);
    image_cut_after = imcrop(image_initial_after, rect_temp);
    image_resize_before = imresize(image_cut_before, [1700 508]);
    image_resize_after = imresize(image_cut_after, [1700 508]);
    
    % 存储裁切后的图片和变换后的图片
    Filename_cut_before = ['TP_cut_before',num2str(N),'mm.bmp'];
    imwrite(image_cut_before,fullfile(filepath_output, Filename_cut_before)); 
    Filename_resize_before = ['TP_before_resize',num2str(N),'mm.bmp'];
    Image_before_file=fullfile(filepath_output, Filename_resize_before);
    imwrite(image_resize_before,Image_before_file); 

    Filename_cut_after = ['TP_cut_after',num2str(N),'mm.bmp'];
    imwrite(image_cut_before,fullfile(filepath_output, Filename_cut_after)); 
    Filename_resize_after = ['TP_after_resize',num2str(N),'mm.bmp'];
    Image_after_file=fullfile(filepath_output, Filename_resize_after);
    imwrite(image_resize_after,Image_after_file); 

end