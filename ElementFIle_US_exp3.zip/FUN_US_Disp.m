function [P_FEM_to_Fig,P_FEM_to_Axial,displacements_new]=FUN_US_Disp(scale_US_FEM,scale_FEM_Fig,Target_nodes,Lateral,Axial,nodes_phantom_corse,Zmax_US,T_axial_FEM,T_fig_FEM)
Position_FEM(:,1)=nodes_phantom_corse(Target_nodes,1);
Position_FEM(:,2)=nodes_phantom_corse(Target_nodes,3);

Position_FEM_rot(:,1)=Position_FEM(:,1);
Position_FEM_rot(:,2)=Zmax_US-Position_FEM(:,2);
[n_ROI,~]=size(Position_FEM);

P_FEM_to_Axial=zeros(n_ROI,2);
P_FEM_to_Fig=zeros(n_ROI,2);
displacements=zeros(n_ROI,2);

for i=1:n_ROI
    P_FEM_to_Axial(i,:)=Position_FEM_rot(i,:)./scale_US_FEM+T_axial_FEM;   % 有限元结点对应的axial下的像素坐标
    P_FEM_to_Axial(i,:)=round(P_FEM_to_Axial(i,:)); % 取整后的像素坐标
    y = P_FEM_to_Axial(i, 1);% 获得目标点在超声图像坐标系下的横纵坐标值
    x = P_FEM_to_Axial(i, 2);    
    P_FEM_to_Fig(i,:)=Position_FEM_rot(i,:).*scale_FEM_Fig+T_fig_FEM;   % 有限元结点对应的Fig下的像素坐标
    P_FEM_to_Fig(i,:)=round(P_FEM_to_Fig(i,:)); % 取整后的像素坐标
    displacementX = Lateral(x,y);
    displacementY = -Axial(x,y);
    displacements(i, :) = [displacementX, displacementY];%displacements是一个Nx2的矩阵，包含位置矩阵中每个点对应的最接近图像点的横向位移和纵向位移
    % 注意，Axial里面的位移场方向是相对于Axial坐标系的，所以Axial的方向应该变换一下
end
displacements_temp=displacements.*scale_US_FEM;
displacements_new=displacements_temp';
displacements_new=displacements_new(:);%displacements是一个2N的一维向量，对应于2D截面的位移场；
end