function [node_new,U_2D]=FUN_2D_FEM(scale,alpha)
%% the 2D FEM model 
load('D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\node_corse.mat');
load('D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\Face_Tri.mat');
load('D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\Face_tri_circle.mat');
load('D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\Face_tri_rest.mat');
load('D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\FaceNode_2D.mat');
load('D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\DKKG_Face2D_Res.mat');
load('D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\DKKG_Face2D_circle.mat');
load('D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\Line_node_down.mat');
load('D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\Line_node_up.mat');
% load node_corse.mat
% load Face_Tri.mat
% load Face_tri_circle.mat
% load Face_tri_rest.mat
% load FaceNode_2D.mat
% load DKKG_Face2D_Res.mat
% load DKKG_Face2D_circle.mat
% load Line_node_down.mat
% load Line_node_up.mat
%%
% scale=5;%这里指的是被压缩的位移大小
% alpha=1;%待输入的参数
% t=1;
% NU=0.49;
% p=2;
E=1e4;
nnode=size(node_corse,1);
nnode_Face=length(FaceNode_2D);
% DKKG_Face2D_Res=Compute_DKKG_Tri_yz(node_corse,FaceNode_2D,Face_tri_rest,NU,p);
% DKKG_Face2D_circle=Compute_DKKG_Tri_yz(node_corse,FaceNode_2D,Face_tri_circle,NU,p);
% save('DKKG_Face2D_Res.mat','DKKG_Face2D_Res')
% save('DKKG_Face2D_circle.mat','DKKG_Face2D_circle')
KKG=E*(alpha*DKKG_Face2D_circle+DKKG_Face2D_Res);
diag(full(KKG));
Constrain_fix_map=mapsetID(nnode,FaceNode_2D,Line_node_up);% 2D有限元底边上的点
Constrain_move_map=mapsetID(nnode,FaceNode_2D,Line_node_down);% 2D有限元底边上的点
Lf=cal_ob_map_2D(nnode_Face,Constrain_fix_map);
Lm1=cal_ob_map_2D_wz_sigle(nnode_Face,Constrain_move_map,2);% 这里代表控制y方向位移
Lm2=cal_ob_map_2D_wz_sigle(nnode_Face,Constrain_move_map,1);% 这里代表控制z方向位移

Lf_all=[Lf;Lm1];
Lm_all=Lm2;% 这里指的是施加的强制位移，沿着z方向的

Lk_all=[Lf_all;Lm_all];
nKB_all=size(Lk_all,1);
MB_F=zeros(2*nnode_Face,1);%% force=0;
nf=size(Lf_all,1);
nm=size(Lm_all,1);
U1=zeros(nf,1);%% 这里是约束指定的点的xyz方向位移为0.
U2=ones(nm,1)*scale;%% 这里是约束指定的点的z方向位移为scale.
KB_U=[U1;U2];
M_left=[MB_F;KB_U];

Kall_U2=sparse(2*nnode_Face+nKB_all,2*nnode_Face+nKB_all);
Kall_U2(1:2*nnode_Face,1:2*nnode_Face)=KKG;
Kall_U2(2*nnode_Face+1:2*nnode_Face+nKB_all,1:2*nnode_Face)=Lk_all;
Kall_U2(1:2*nnode_Face,2*nnode_Face+1:2*nnode_Face+nKB_all)=Lk_all';

%% 直接求逆
M_right=Kall_U2\M_left;
U_2D=M_right(1:2*nnode_Face);
%% 将2D计算的位移场转换到3D空间
U2new=reshape(U_2D,2,length(U_2D)/2);
U2new=U2new';
% U2new_final=[U2new(:,1),zeros(size(U2new(:,1))),U2new(:,2)];
U2new_final=[zeros(size(U2new(:,1))),U2new(:,1),U2new(:,2)];
% U2_expand=U2new_final';
% U2_expand=U2_expand(:);
U2_global=zeros(nnode,3);
U2_global(FaceNode_2D,:)=U2new_final;
node_new=node_corse+U2_global;
%% plot
Plot_2D_FEM(node_new,Face_tri_rest,Face_tri_circle,scale,alpha)
end