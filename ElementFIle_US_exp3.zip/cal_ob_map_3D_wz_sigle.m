function ob_map=cal_ob_map_3D_wz_sigle(nnode,Control_ID,j)
Cnum=length(Control_ID);
map_matrix=zeros(Cnum,3*nnode);

for i=1:Cnum
    if j==1
        map_matrix_id=3*Control_ID(i)-2;
    elseif j==2
        map_matrix_id=3*Control_ID(i)-1;
    else
        map_matrix_id=3*Control_ID(i);
    end 
    map_matrix(i,map_matrix_id)=1;
end

ob_map=map_matrix;