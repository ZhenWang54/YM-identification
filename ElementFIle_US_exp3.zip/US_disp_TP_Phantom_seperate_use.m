%% 这个是从假体和贴片一起的超声图像中获取耦合节点、假体目标区域节点对应的位移
% clear;
% clc;
% close all;
load 0715_exp3_node_corse.mat %加载整体节点对应的初始坐标
load 0715_exp3_RegionNode_US.mat % 被选择去计算位移场的节点
load 0715_exp3_nodes_TP_corse.mat
load 0715_exp3_nodes_phantom_corse.mat
% load 0715_exp3_nodes_TP_2D.mat % 这个是在整体节点下的编号
load 0715_exp3_nodes_TP_2D_new.mat %这个是在贴片自身节点下的编号
load 0715_exp3_Line_node_up.mat % 这个是在整体节点下的编号
load 0715_exp3_FaceNode_US_3D.mat
nodes_TP_2D=nodes_TP_2D_new;
R=8;
Zmax_TP=38.8;
if (R==8)
    scale_X=6.228;% 表示截屏图像X像素尺寸和实际尺寸的比例
    scale_Y=10.2;% 表示截屏图像Y像素尺寸和实际尺寸的比例
%     scale_X=7.226;% 表示截屏图像X像素尺寸和实际尺寸的比例
%     scale_Y=10.2;% 表示截屏图像Y像素尺寸和实际尺寸的比例
elseif ( R==5)
    scale_X=6.375;% 表示截屏图像X像素尺寸和实际尺寸的比例
    scale_Y=9.885;% 表示截屏图像Y像素尺寸和实际尺寸的比例
end
T_tran=[-15,-40];%表示US处理位移场丢掉的边框尺寸，这个和GLUE算法相关
P_FEM_center_P=[16,24.5];% 有限元下的假体中心点位置，这个是正常坐标系下的位置
P_FEM_center_TP=[16,6.8];% 有限元下的假体中心点位置，这个是翻转后的
figure,scatter3(nodes_phantom_corse(:,1),nodes_phantom_corse(:,2),nodes_phantom_corse(:,3));
%% 计算位移场，根据原始截屏图像,计算贴片的位移场
FilePath_before='F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\temp_data\before1.bmp';
FilePath_after='F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\temp_data\after1.bmp';
%%
RegionNode_US_all=[RegionNode_US;Line_node_up];
displacements_Phantom=FUN_disp_P_2(FilePath_before,FilePath_after,scale_X,scale_Y,T_tran,P_FEM_center_P,nodes_phantom_corse,RegionNode_US_all);
save('displacements_Phantom_temp.mat','displacements_Phantom')
%% 求取贴片底部的位移场
% rect_TP=[644  168  2507   87];
% rect_TP_before=rect_TP;
% rect_TP_after=rect_TP;
% [image_cut_before_TP,image_resize_before,image_resize_after]=FUN_Image_preprocess_TPandPhantom_2(FilePath_before,FilePath_after,rect_TP_before,rect_TP_after);
displacements_TP_Z=FUN_disp_TP_2(FilePath_before,FilePath_after,scale_X,scale_Y,T_tran,P_FEM_center_TP,nodes_TP_corse,nodes_TP_2D,Zmax_TP);
U2_TP_Disp=displacements_TP_Z;
save('0715_exp3_U2_TP_Disp.mat','U2_TP_Disp');
%% 根据假体2D的强制位移场，求解3D下的对应的强制位移场
coefficient=1.165;
% coefficient=1;
load displacements_Phantom_temp.mat;
n_nodes_region=size(RegionNode_US,1);
U2_real_Local=displacements_Phantom(1:2*n_nodes_region);
Forcedisp_Phantom_2D=displacements_Phantom(2*n_nodes_region+2:2:end);
[nodes_TP_corse_add,nodes_phantom_corse,Forcedisp_Phantom_3D]=Map_disp_TP(Line_node_up,Forcedisp_Phantom_2D,FaceNode_US_3D,nodes_phantom_corse,coefficient); %% 将2D截面下边界的位移场映射至3D的底面
save('0715_exp3_Forcedisp_Phantom_3D.mat','Forcedisp_Phantom_3D');
save('0715_exp3_Forcedisp_Phantom_2D.mat','Forcedisp_Phantom_2D');
save('0715_exp3_U2_real_Local.mat','U2_real_Local');
figure,scatter3(Forcedisp_Phantom_3D(:,1),Forcedisp_Phantom_3D(:,2),Forcedisp_Phantom_3D(:,3))
Plot_scatter3(nodes_phantom_corse,FaceNode_US_3D);
