function alpha_3D_US=Plot_Kriging_US(alpha3D_set,alpha2D_set,alpha3D_set_test,alpha2D_set_test,N,alpha_2D_US)
% 根据训练集基于Kriging预测3D比杨氏模量
figure(N);
left = 300;     % 窗口左边距离屏幕左边的距离（以像素为单位）
bottom = 300;   % 窗口顶部距离屏幕底部的距离（以像素为单位）
width = 700;    % 窗口的宽度（以像素为单位）
height = 400;   % 窗口的高度（以像素为单位）

FontSizeNumber=30;
FontSizeNumber2=20;
FontSizeNumber3=3;
FontSizeNumber4=4;
FontSizeNumberLegend=28;
X=alpha2D_set;
Y=alpha3D_set;
a=max(alpha2D_set);
theta = 1;
lob = 1e-1; upb = 20;
[dmodel, ~] = dacefit(X, Y, @regpoly0, @corrgauss, theta, lob, upb);
Ylabel_set=[X;Y];
[Y_precict,~]=predictor(alpha2D_set_test, dmodel);
[alpha_3D_US,~]=predictor(alpha_2D_US, dmodel);
Error1=abs(alpha2D_set_test-alpha3D_set_test);
R_error1=Error1./alpha3D_set_test*100;
Error2=abs(Y_precict-alpha3D_set_test);
R_error2=Error2./alpha3D_set_test*100;
subplot(2,1,1);
hold on;
plot(alpha3D_set_test,alpha2D_set_test,'.-k', 'MarkerSize',FontSizeNumber2,'LineWidth',FontSizeNumber3)
plot(alpha3D_set_test,Y_precict,'.-b', 'MarkerSize',FontSizeNumber2,'LineWidth',FontSizeNumber3)
xlim([0,9]);
xlabel('True value \alpha_{3D}','FontSize', FontSizeNumber);% 给左y轴添加轴标签
set(gca,'FontName','times new Roman','FontSize', FontSizeNumber,'FontWeight','bold');
legend(' $\alpha_{2D}$','$\alpha_{k}$','Location','northwest','Interpreter','latex','FontSize', FontSizeNumberLegend);
% legend(' $\alpha_{2D}$','$\alpha_{k}$','True value $\alpha$','Location','northwest','Interpreter','latex','FontSize', FontSizeNumberLegend);
subplot(2,1,2);
hold on;
plot(alpha3D_set_test,R_error1,'--k','MarkerSize',FontSizeNumber2,'LineWidth',FontSizeNumber4)
plot(alpha3D_set_test,R_error2,'--b','MarkerSize',FontSizeNumber2,'LineWidth',FontSizeNumber4);
xlim([0,9]);clc
xlabel('True value \alpha_{3D}','FontSize', FontSizeNumber);% 给左y轴添加轴标签
set(gca,'FontName','times new Roman','FontSize', FontSizeNumber,'FontWeight','bold');
legend('$\alpha_{2D}$','$\alpha_{k}$','Location','northwest','Interpreter','latex','FontSize', FontSizeNumberLegend);
set(N, 'Position', [left, bottom, width, height]);
hold off
