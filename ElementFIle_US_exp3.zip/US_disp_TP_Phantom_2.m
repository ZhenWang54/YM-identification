%% 这个是从假体和贴片一起的超声图像中获取耦合节点、假体目标区域节点对应的位移,US_disp_Phantom_2和US_disp_Phantom的区别在于
%% 2是基于函数的方式进行编写的，更加简洁
clear;clc;close all;
load 0715_exp2_node_corse.mat %加载整体节点对应的初始坐标
load 0715_exp2_RegionNode_US.mat % 被选择去计算位移场的节点
load 0715_exp2_nodes_TP_corse.mat
load 0715_exp2_nodes_phantom_corse.mat
load 0715_exp2_nodes_TP_2D_new.mat %这个是在贴片自身节点下的编号
load 0715_exp2_map_couple.mat
nodes_TP_2D=nodes_TP_2D_new;
R=8;
%%
Zmax_TP=38;
if (R==8)
    scale_X=6.228;% 表示截屏图像X像素尺寸和实际尺寸的比例
    scale_Y=10.2;% 表示截屏图像Y像素尺寸和实际尺寸的比例
    scale_FEM_Fig=[scale_X,scale_Y];
%     scale_X=7.226;% 表示截屏图像X像素尺寸和实际尺寸的比例
%     scale_Y=10.2;% 表示截屏图像Y像素尺寸和实际尺寸的比例
elseif ( R==5)
    scale_X=6.375;% 表示截屏图像X像素尺寸和实际尺寸的比例
    scale_Y=9.885;% 表示截屏图像Y像素尺寸和实际尺寸的比例
end
T_tran=[-15,-40];%表示US处理位移场丢掉的边框尺寸，这个和GLUE算法相关
P_FEM_center=[15.5,14.3];% 有限元下的假体中心点位置，这个是翻转后的,贴片厚度是6mm，对应zmax=38；
P_FEM_TP=[15.5,6.8];
%% 计算位移场，根据原始截屏图像
FilePath_before='F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp2\US_data_20230715\temp_data\exp2\before1.bmp';
FilePath_after='F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp2\US_data_20230715\temp_data\exp2\after2.bmp';
[image_cut_before,rect,image_resize_before,image_resize_after]=FUN_Image_preprocess_TPandPhantom(FilePath_before,FilePath_after);
[Axial, Lateral]=FUN_glue2(image_resize_before,image_resize_after);
% close(1,2,3,4);
%% 针对假体，获取假体对应的位移场数据
image_cut_before1=image_cut_before;
disp('选择假体圆心位置')
[P_center_cut,x_center, y_center]=FUN_get_center_node(image_cut_before1);% 选取裁切图像中圆心的位置
disp(P_center_cut);
% P_center_cut=[110.012911286964,160.869012911287];
image_cut_before2=image_cut_before;
disp('选择贴片底部中间位置')
[P_TP,x_TP, y_TP]=FUN_get_center_node(image_cut_before2);
disp(P_TP);
imshow(image_cut_before);
hold on;
scatter(x_center, y_center, 'ro', 'filled');
scatter(x_TP, y_TP, 'go', 'filled');
hold off;
% P_center_cut=[210.7613  130.9421];
scale_reviseX=rect(3)/508;%表示裁切的图像到US变换的横向变换比例
scale_reviseY=rect(4)/1700;%表示裁切的图像到US变换的纵向变换比例
scale_revise=[scale_reviseX,scale_reviseY];
scale_US_FEM=[scale_reviseX/scale_X,scale_reviseY/scale_Y];% 这里表示超声位移场中的像素坐标与实际mm坐标之间的尺度变换
P_center_US=P_center_cut./scale_revise;% 超声初始图片里，圆心的位置
% P_center_US=[254,868];
P_test_US=P_TP./scale_revise;
P_test_Axial=P_test_US+T_tran;
P_center_Axial=P_center_US+T_tran;% 超声位移场Axial中，圆心的位置（有一个裁切）
%% 是把FEM的尺寸变换到Axial里面，求取对应的位移场，然后再变换回FME。
P_center_FEM_to_Axial=P_FEM_center./scale_US_FEM;% Axial下的圆心位置
T_axial_FEM=P_center_Axial-P_center_FEM_to_Axial;

P_test_FEM_to_Axial=P_FEM_TP./scale_US_FEM;% Axial下的贴片位置
T_axial_FEM_TP=P_test_Axial-P_test_FEM_to_Axial;

P_center_FEM_to_Fig=P_FEM_center.*scale_FEM_Fig;% 图像下的圆心位置
T_fig_FEM=P_center_cut-P_center_FEM_to_Fig;

P_TP_FEM_to_Fig=P_FEM_TP.*scale_FEM_Fig;% 图像下的圆心位置
T_fig_FEM2=P_TP-P_TP_FEM_to_Fig;
%% 计算有限元网格结点对应的位移场

[P_FEM_to_Fig1,P_FEM_to_Axial,displacements_new1]=FUN_US_Disp(scale_US_FEM,scale_FEM_Fig,RegionNode_US,Lateral,Axial,nodes_phantom_corse,Zmax_TP,T_axial_FEM,T_fig_FEM);
U2_real_Local=displacements_new1;
[P_FEM_to_Fig2,P_FEM_to_Axial2,displacements_new2]=FUN_US_Disp(scale_US_FEM,scale_FEM_Fig,nodes_TP_2D,Lateral,Axial,nodes_TP_corse,Zmax_TP,T_axial_FEM_TP,T_fig_FEM2);
U2_TP_Disp=displacements_new2;

save('0715_exp2_U2_real_Local.mat','U2_real_Local');
save('0715_exp2_U2_TP_Disp.mat','U2_TP_Disp');
%% 计算三维场景下的贴片底面对应的位移场
coefficient_map_Disp=1;
coefficient_all_disp=1;
Map_TP_ID=map_couple(:,2);
Map_Phantom_ID=map_couple(:,1);
node_orign_ID=nodes_TP_2D;
nn_TP_disp=size(U2_TP_Disp,1)/2;
node_orign_add=zeros(nn_TP_disp,1);
for i=1:nn_TP_disp
    node_orign_add(i)=U2_TP_Disp(2*i);
end
[nodes_TP_corse_add,nodes_TP_corse,nodes_TP_DISP]=Map_disp_TP(node_orign_ID,node_orign_add,Map_TP_ID,nodes_TP_corse,coefficient_map_Disp); %% 将2D截面下边界的位移场映射至3D的底面

save('0715_exp2_nodes_TP_DISP.mat','nodes_TP_DISP')
%% 
figure, imagesc(Axial), colorbar, title('axial displacement'), colormap(hot);
hold on
scatter(P_FEM_to_Axial(:,1),P_FEM_to_Axial(:,2),'k'); % 显示有限元的节点
scatter(P_FEM_to_Axial2(:,1),P_FEM_to_Axial2(:,2),'k'); % 显示有限元的节点

P_center_Axial=P_center_Axial';
P_center_FEM_to_Axial=P_center_FEM_to_Axial';
scatter(P_center_FEM_to_Axial(1),P_center_FEM_to_Axial(2),'+g');% +号表示有限元的中心点（没平移变换之前的）
scatter(P_center_Axial(1),P_center_Axial(2),'*b'); % 手动选择的超声图像中的点
scatter(P_test_Axial(:,1),P_test_Axial(:,2),'*g'); % 手动选择的超声图像中的点
hold off
%%
figure(110),
imshow(image_cut_before);
hold on
scatter(P_FEM_to_Fig1(:,1),P_FEM_to_Fig1(:,2),'r'); % 显示有限元的节点
scatter(P_FEM_to_Fig2(:,1),P_FEM_to_Fig2(:,2),'r'); % 显示有限元的节点