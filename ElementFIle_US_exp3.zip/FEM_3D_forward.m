% 计算3D正向模型,基于位移约束情况
clear;
clc;
close all;

load 0715_exp3_element_back_corse.mat
load 0715_exp3_element_circle_corse.mat
load 0715_exp3_nodes_phantom_corse.mat
load 0715_exp3_element_phantom_new.mat
% load 0715_exp3_DKKG_cylinder.mat
% load 0715_exp3_DKKG_block.mat
load 0715_exp3_FaceNode_up_3D.mat
load 0715_exp3_FaceNode_down_3D.mat
load 0715_exp3_FaceNode_US_3D.mat
NU=0.49;

node_corse=nodes_phantom_corse;

tic;
DKKG_block=Compute_DKKG_Tetra(node_corse,element_back_corse,NU);
DKKG_cylinder=Compute_DKKG_Tetra(node_corse,element_circle_corse,NU);
toc;
figure,tetramesh(element_back_corse,node_corse);
hold on
tetramesh(element_circle_corse,node_corse);
hold off
save('0715_exp3_DKKG_block.mat','DKKG_block')
save('0715_exp3_DKKG_cylinder.mat','DKKG_cylinder')
%%
alpha=1;
scale=2;
nnode=size(node_corse,1);
Lf=cal_ob_map(nnode,FaceNode_US_3D);% 超声固定边界
nKB_sub1=size(Lf,1);

Lmx=cal_ob_map_3D_wz_sigle(nnode,FaceNode_down_3D,1);% 底部固定边界
Lmy=cal_ob_map_3D_wz_sigle(nnode,FaceNode_down_3D,2);% 底部固定边界
Lmz=cal_ob_map_3D_wz_sigle(nnode,FaceNode_down_3D,3);% 底部移动边界

Lm_xyz=[Lmx;Lmy;Lmz];
Lk_all=[Lf;Lm_xyz];
nKB_all=size(Lk_all,1);

nKB_sub2x=size(Lmx,1);
nKB_sub2y=size(Lmy,1);
nKB_sub2z=size(Lmz,1);

E=1e4;
KKG=E*(alpha*DKKG_cylinder+DKKG_block);
MB_F=zeros(3*nnode,1);%% 力载荷


KB_Uus=zeros(nKB_sub1,1);%% 固定边界约束
KB_Ux=zeros(nKB_sub2x,1);%% 固定边界约束
KB_Uy=zeros(nKB_sub2y,1);%% 固定边界约束

KM_U=ones(nKB_sub2z,1)*scale;%% 移动边界约束
KF_U=[KB_Uus;KB_Ux;KB_Uy];

%U2 (Measured Force)
Kall_U2=sparse(3*nnode+nKB_all,3*nnode+nKB_all);
Kall_U2(1:3*nnode,1:3*nnode)=KKG;
Kall_U2(3*nnode+1:3*nnode+nKB_all,1:3*nnode)=Lk_all;
Kall_U2(1:3*nnode,3*nnode+1:3*nnode+nKB_all)=Lk_all';

%Pesudo Force
PFall_U2=[MB_F;KF_U;KM_U];
%Pesudo Displacement
PUall_U2=Kall_U2\PFall_U2;
U2=PUall_U2(1:3*nnode);
UUG=U2;
A=reshape(UUG,3,length(UUG)/3);
A=A';
UUG_3D_all=UUG;
%%
plotFEMtetra(node_corse,element_back_corse,element_circle_corse,U2)
title(['sidefix_x bottomfix_yz 3D deform, alpha=',num2str(alpha)]);


