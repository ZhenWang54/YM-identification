function [face_node_up,face_node_down]=Find_node_TP(~,~,~,~,zmin,zmax,Node_all)
x=Node_all(:,1);
y=Node_all(:,2);
z=Node_all(:,3);
face_node_up=find(z>=zmax-0.1);
face_node_down=find(z<=zmin+0.1);
end