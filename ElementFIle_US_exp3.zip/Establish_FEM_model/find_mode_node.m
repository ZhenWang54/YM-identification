function face_node=find_mode_node(x_min,x_max,y_min,y_max,z_min,z_max,Node_all)
z=Node_all(:,3);
y=Node_all(:,2);
x=Node_all(:,1);
x0_max=x_max+0.01;
x0_min=x_min-0.01;
z0_max=z_max+0.01;
z0_min=z_min-0.01;
y0_max=y_max+0.01;
y0_min=y_min-0.01;
face_node=find(x>=x0_min & x<x0_max & z>=z0_min & z<z0_max & y>=y0_min & y<y0_max);
end