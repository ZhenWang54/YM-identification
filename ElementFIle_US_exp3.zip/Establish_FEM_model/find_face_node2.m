function face_node=find_face_node2(z0,Node_all)
z=Node_all(:,3);
z0_max=z0+0.1;
z0_min=z0-0.1;
face_node=find(z>=z0_min & z<z0_max);
end