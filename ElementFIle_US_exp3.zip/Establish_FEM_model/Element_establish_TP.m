%% 用作建立贴片的有限元模型，验证力学性能
clear;
clc;
close all;
%% 建立2D有限元模型和3D有限元模型的单元
%% 获得旋转后的点位置和element
load ElementTP4.mat
load Node_TP4.mat
% load Element0625.mat
% load Node0625.mat
node_temp=Node_TP4;
element_temp=ElementTP4;
%%
theta=0;
theta1=0;
theta2=0;
box_high_add1=0;
box_high_add2=0;
box_high_add3=0;
%%
Ry = [ cos(theta1), 0, sin(theta1);0,1,0;-sin(theta1), 0, cos(theta1) ];
Node_rot=node_temp(:,2:4)';
Node_rot_new=Ry*Node_rot;
Node_rot_new=Node_rot_new';
% Node_rot_new(:,3)=Node_rot_new(:,3)+box_high_add;
% 绕x轴旋转
Rx = [ 1, 0, 0;0,cos(theta),sin(theta);0, -sin(theta), cos(theta) ];
Node_rot_new=Rx*Node_rot_new';
Node_rot_new=Node_rot_new';

% 绕z轴旋转
Rz = [ cos(theta2), sin(theta2), 0;-sin(theta2),cos(theta2),0;0, 0, 1 ];
Node_rot_new=Rz*Node_rot_new';
Node_rot_new=Node_rot_new';
Node_rot_new(:,1)=Node_rot_new(:,1)+box_high_add1;
Node_rot_new(:,2)=Node_rot_new(:,2)+box_high_add2;
Node_rot_new(:,3)=Node_rot_new(:,3)+box_high_add3;

node_corse=Node_rot_new;
node_corse=round(node_corse,5);
element_corse=element_temp(:,2:5);

currentPath = pwd;  % 获取当前路径
[parentPath, ~, ~] = fileparts(currentPath);  % 获取上一级路径
%% 3D有限元
figure(1),tetramesh(element_corse,node_corse)
hold on
xlabel('x');
ylabel('y');
zlabel('z');

% filename_Elemen1 = fullfile(parentPath, '80_element_back_corse.mat'); 
% save(filename_Elemen1,'element_back_corse');
%% 2D有限元
% 整个截面
[face_node_up_ID,face_node_down_ID]=Find_node_TP(0,0,0,0,0,7,node_corse);% 2D有限元的截面结点


face_node_up_corse=node_corse(face_node_up_ID,:);
face_node_down_corse=node_corse(face_node_down_ID,:);
figure(5),scatter3(face_node_up_corse(:,1),face_node_up_corse(:,2),face_node_up_corse(:,3))
axis equal
hold on
scatter3(face_node_down_corse(:,1),face_node_down_corse(:,2),face_node_down_corse(:,3))
axis equal

OutputPath='D:\onedrive\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US';
filename_node = fullfile(OutputPath, 'TP_4_face_node_up_ID.mat');  % 创建完整的文件路径
save(filename_node,'face_node_up_ID');
filename_node = fullfile(OutputPath, 'TP_4_face_node_down_ID.mat');  % 创建完整的文件路径
save(filename_node,'face_node_down_ID');
