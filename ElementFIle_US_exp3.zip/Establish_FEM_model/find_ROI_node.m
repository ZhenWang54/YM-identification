function face_node=find_ROI_node(xmin,xmax,y_face,zmin,zmax,Node_all)
x=Node_all(:,1);
y=Node_all(:,2);
z=Node_all(:,3);
face_node=find(y==y_face & z>=zmin & z<=zmax & x>=xmin & x<=xmax);
end