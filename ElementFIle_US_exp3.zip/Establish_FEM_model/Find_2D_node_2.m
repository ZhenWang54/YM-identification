function face_node=Find_2D_node_2(y_face,zmin,zmax,Node_all)
y=Node_all(:,2);
z=Node_all(:,3);
face_node=find(y>=y_face-0.01 & y<=y_face+0.01 & z>=zmin-0.01 & z<=zmax+0.01);
end