function [Line_node_up,Line_node_down]=Find_2line_Node(Node_all,zmax_2D,zmin_2D,Y_center)
x=Node_all(:,1);
y=Node_all(:,2);
z=Node_all(:,3);
Line_node_up=find(y>=Y_center-0.1 & y<Y_center+0.1 & z>=zmax_2D-0.1 & z<=zmax_2D+0.1);
Line_node_down=find(y>=Y_center-0.1 & y<=Y_center+0.1 & z<=zmin_2D+0.1);
end