function face_node=find_RIO_node(y_face,zmin,zmax,Node_all)
x=Node_all(:,1);
y=Node_all(:,2);
z=Node_all(:,3);
face_node=find(y==y_face & y>=zmin & y<=zmax & y>=zmin & y<=zmax);
end