function [Tnew,T_res]=TetraElementSelect(T,node_ID)

Tri_pool=ismember(T,node_ID);
Tri_pool=sum(Tri_pool,2);
Tri_ID=find(Tri_pool==4);
Tnew=T(Tri_ID,:);

ID_all=1:length(Tri_pool);
ID_res=setxor(ID_all,Tri_ID);%setxor is get the nonset's complement
T_res=T(ID_res,:);