function [node_corse,element_corse]= FUN_rotaionxyz(theta,theta1,theta2,box_high_add1,box_high_add2,box_high_add3,Nodes_all_N,Element_all_N)
Ry = [ cos(theta1), 0, sin(theta1);0,1,0;-sin(theta1), 0, cos(theta1) ];
Node_rot=Nodes_all_N(:,2:4)';
Node_rot_new=Ry*Node_rot;
Node_rot_new=Node_rot_new';
% Node_rot_new(:,3)=Node_rot_new(:,3)+box_high_add;
% 绕x轴旋转
Rx = [ 1, 0, 0;0,cos(theta),sin(theta);0, -sin(theta), cos(theta) ];
Node_rot_new=Rx*Node_rot_new';
Node_rot_new=Node_rot_new';

% 绕z轴旋转
Rz = [ cos(theta2), sin(theta2), 0;-sin(theta2),cos(theta2),0;0, 0, 1 ];
Node_rot_new=Rz*Node_rot_new';
Node_rot_new=Node_rot_new';
Node_rot_new(:,1)=Node_rot_new(:,1)+box_high_add1;
Node_rot_new(:,2)=Node_rot_new(:,2)+box_high_add2;
Node_rot_new(:,3)=Node_rot_new(:,3)+box_high_add3;

node_corse=Node_rot_new;
node_corse=round(node_corse,5);
element_corse=Element_all_N(:,2:5);

end