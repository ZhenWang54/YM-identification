function Tnew=OmitRepeatElement(T)

T_tmp=T;
T_tmp=sort(T_tmp,2);
[~,ID,~]=unique(T_tmp,'rows');

Tnew=T(ID,:);