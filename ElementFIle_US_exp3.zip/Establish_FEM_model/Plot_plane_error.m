function Plot_plane_error(U,Error_U,colmin,colmax)
% load node_new_final.mat;%% 加载全部节点位置信息3.N

load node_corse.mat;
load Face3_Tri_circle.mat;
load Face3_Tri_Res.mat;
load Face3_ID.mat;

% load Observe_face_patch.mat;%% 加载平面三角单元3.N的数据
% U是位移信息，Error_U 是误差信息，；两者都为3*nNode的一列向量

node=node_corse;
nnode=length(node);
face_element=[Face3_Tri_circle;Face3_Tri_Res];

ID_ob=face_element(:);%找到单元对应的所有节点号
ID_ob=unique(ID_ob);%找到单元对应的所有节点号
col_ob=zeros(nnode,1);%新建所有节点
Er_new=reshape(Error_U,3,552/3);%位移误差也是全局节点的
Er_new=Er_new';
col=sum(abs(Er_new).^2,2).^(1/2);%计算结点处的位移误差
col_ob(ID_ob)=col;%将局部结点位移映射到全局结点位移上

n_U=length(U)/3;
U_tmp=reshape(U,3,n_U);
U_tmp=U_tmp';

U_tmp_ave=sum(abs(U_tmp).^2,2).^(1/2);
U_tmp_max=max(U_tmp_ave);
col_ob=100*col_ob/U_tmp_max;

node_zero=zeros(nnode,3);
node_zero(ID_ob,1:3)=U_tmp(:,1:3);
node_new=node+node_zero;

patch('Faces',face_element,'Vertices',node_new,'FaceVertexCData',col_ob,'FaceColor','interp','FaceAlpha',1,'EdgeAlpha',0.3,'EdgeColor','k')

hold off
colormap('jet') 
colorbar
caxis([colmin,colmax])


set(gca,'FontName','times new Roman','FontSize',30)
set(gcf,'Position',[100,100,900,800])
view(-0 ,0)