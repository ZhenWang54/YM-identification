function Plot_scatter3(node_corse,nodes_ID)
figure,
scatter3(node_corse(nodes_ID,1),node_corse(nodes_ID,2),node_corse(nodes_ID,3))
axis equal
hold on 
xlabel('x');
ylabel('y');
zlabel('z');
end


