function plot_nodes(Node_ID,Node_all,N)
figure(N)
n=size(Node_ID,1);
positions=zeros(n,3);
    for i=1:n
        positions(i,1)=Node_all(Node_ID(i),1);
        positions(i,2)=Node_all(Node_ID(i),2);
        positions(i,3)=Node_all(Node_ID(i),3);
    end
scatter3(positions(:,1), positions(:,2), positions(:,3), 'filled');
xlabel('x');
ylabel('y');
zlabel('z');
end