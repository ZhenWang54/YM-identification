clear;
clc;
close all;
%% 建立2D有限元模型和3D有限元模型的单元
%% 获得旋转后的点位置和element
load Element80.mat
load Node80.mat
% load Element0625.mat
% load Node0625.mat
node_temp=Node80;
element_temp=Element80;
%%
theta=pi/2;
theta1=0;
theta2=pi;
box_high_add1=31;
box_high_add2=32;
box_high_add3=31.5;
%%
[node_corse,element_corse]= FUN_rotaionxyz(theta,theta1,theta2,box_high_add1,box_high_add2,box_high_add3,Nodes_all_N,Element_all_N);
currentPath = pwd;  % 获取当前路径
[parentPath, ~, ~] = fileparts(currentPath);  % 获取上一级路径
%% 3D有限元
center=[15.5 24];
r=4.7;
node_circle_corse=find_in_circle2(node_corse,center,r);
node_circle=node_corse(node_circle_corse,:);
figure(5),scatter3(node_circle(:,1),node_circle(:,2),node_circle(:,3))
axis equal

[element_circle_corse,element_back_corse]=TetraElementSelect(element_corse,node_circle_corse);
figure(1),tetramesh(element_circle_corse,node_corse)
hold on
xlabel('x');
ylabel('y');
zlabel('z');
figure(2),tetramesh(element_back_corse,node_corse)
hold on
xlabel('x');
ylabel('y');
zlabel('z');
filename_Elemen1 = fullfile(parentPath, '80_element_circle_corse.mat'); 
save(filename_Elemen1,'element_circle_corse');
filename_Elemen1 = fullfile(parentPath, '80_element_back_corse.mat'); 
save(filename_Elemen1,'element_back_corse');
%% 2D有限元
% 整个截面
FaceNode_2D=Find_2D_node(16,node_corse);% 2D有限元的截面结点
Face_Tri=Tetra2TriSelect(element_corse,FaceNode_2D);
Face_Tri=OmitRepeatElement(Face_Tri);
[results,Face_Tri]=checkTriDirection_new(Face_Tri,node_corse);
figure,trimesh(Face_Tri,node_corse(:,1),node_corse(:,2),node_corse(:,3))
axis equal
filename_Elemen1 = fullfile(parentPath, '80_Face_Tri.mat'); 
save(filename_Elemen1,'Face_Tri');

% 中间圆形区域

% P_center=[18 16 24.5];
P_center=[center(1) 16 center(2)];
n_face2D=size(FaceNode_2D,1);
Positions=zeros(n_face2D,3);
for i=1:n_face2D
    Positions(i,:)=node_corse(FaceNode_2D(i),:);
end
distances = sqrt(sum((Positions - P_center).^2, 2));
Face_node_circle_temp = find(distances <= r);

Face_node_circle=FaceNode_2D(Face_node_circle_temp);
Face_Tri=Tetra2TriSelect(element_corse,FaceNode_2D);
[result3,Face_Tri_new]=checkTriDirection_new(Face_Tri,node_corse);
[Face_tri_circle,Face_tri_rest]=TriElementSelect(Face_Tri_new,Face_node_circle);
Face_tri_circle=OmitRepeatElement(Face_tri_circle);
Face_tri_rest=OmitRepeatElement(Face_tri_rest);
figure,trimesh(Face_tri_circle,node_corse(:,1),node_corse(:,2),node_corse(:,3),'FaceColor','b');
hold on
trimesh(Face_tri_rest,node_corse(:,1),node_corse(:,2),node_corse(:,3),'FaceColor','y');
hold off
filename_Elemen1 = fullfile(parentPath, '80_Face_tri_circle.mat'); 
save(filename_Elemen1,'Face_tri_circle');
filename_Elemen1 = fullfile(parentPath, '80_Face_tri_rest.mat'); 
save(filename_Elemen1,'Face_tri_rest');
filename_Elemen1 = fullfile(parentPath, '80_node_corse.mat'); 
save(filename_Elemen1,'node_corse');
