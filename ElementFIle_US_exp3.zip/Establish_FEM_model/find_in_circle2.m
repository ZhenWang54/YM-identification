function node_circle=find_in_circle2(Node,center,r)

if size(Node,2)==2
    xz_cord=Node;
else
    xz_cord=Node(:,[1,3]);
end
% r=5;
% center=[18,23.5];

dist_tmp=xz_cord-center;
dist=sum(dist_tmp.^2,2);
node_circle=find(dist<r^2);