function face_node=find_face_node(z_face,ymin,ymax,Node_all)
x=Node_all(:,1);
y=Node_all(:,2);
z=Node_all(:,3);
face_node=find(z==z_face & y>=(ymin-0.2) & y<=(ymax+0.2));
end