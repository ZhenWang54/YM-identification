%从包括贴片的有限元单元和结点中读取出各自的单元和结点，以及输出两者共有结点的映射关系
clear
clc;
close all

x_min_TP=-5.5;
x_max_TP=37.5;

y_max_TP=17.75;
y_min_TP=10.75;
z_max_TP=38.8;
z_min_TP=32;

x_min_P=0;
x_max_P=32;

y_max_P=28.5;
y_min_P=0;

z_max_P=32;
z_min_P=0;

x_min_rio=8;
x_max_rio=24;
z_min_rio=16.5;
z_max_rio=30.5;
Y_center=14.25;
r=4.6;
center=[16,24.5];%圆心对应的坐标
d=7;% 貼片的宽度
%% 读取整体的element和nodes
% 获取当前路径的上一级路径
currentPath = pwd;  % 获取当前路径
[parentPath, ~, ~] = fileparts(currentPath);  % 获取上一级路径

Element_file_phantom_TP='F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\element_nodes\element84_6.txt';
data_element = importdata(Element_file_phantom_TP, '\t', 1); % 读取txt文件，使用制表符分隔符，跳过第一行
Element_all_N=data_element.data;
n=size(Element_all_N,1);
Element_all_N=horzcat ((1:n)',Element_all_N);
filename_Elemen = fullfile(currentPath, 'Element_all_N.mat');  % 创建完整的文件路径
save(filename_Elemen,'Element_all_N');

Nodes_file_phantom_TP='F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US_exp3\US_data_20230715\element_nodes\nodes84_6.txt';
data_node = importdata(Nodes_file_phantom_TP, '\t', 1); % 读取txt文件，使用制表符分隔符，跳过第一行
Nodes_all_N=data_node.data;
filename_node = fullfile(currentPath, 'Nodes_all_N.mat');  % 创建完整的文件路径
save(filename_node,'Nodes_all_N');
%% 旋转
theta=pi/2;theta1=0;theta2=0;box_high_add1=0;box_high_add2=0;box_high_add3=32;
[node_corse,element_corse]= FUN_rotaionxyz(theta,theta1,theta2,box_high_add1,box_high_add2,box_high_add3,Nodes_all_N,Element_all_N);
%% 分离出下面假体的单元和结点
nodes_phantom=find_mode_node(x_min_P,x_max_P,y_min_P,y_max_P,z_min_P,z_max_P,node_corse);
nodes_circle=find_in_circle2(node_corse,center,r);
Plot_scatter3(node_corse,nodes_phantom);Plot_scatter3(node_corse,nodes_circle);
[element_phantom_corse,element_TP_corse]=TetraElementSelect(element_corse,nodes_phantom);
% test=unique(element_phantom_corse(:))-nodes_phantom;
% nodes_phantom=unique(element_phantom_corse(:));
[element_circle_corse,~]=TetraElementSelect(element_corse,nodes_circle);
figure(10),tetramesh(element_phantom_corse,node_corse);
hold on
tetramesh(element_TP_corse,node_corse);
figure(11),tetramesh(element_circle_corse,node_corse);

%% 分离出上面贴片的单元和结点
nodes_TP=unique(element_TP_corse(:));
Plot_scatter3(node_corse,nodes_TP);
nodes_TP_2D=find_mode_node(x_min_P,x_max_P,Y_center,Y_center,z_min_TP,z_min_TP,node_corse);% 这里是只找到与之接触的点
Plot_scatter3(node_corse,nodes_TP_2D);
%% 分离出贴片和假体耦合的节点，以及节点在各自子模块的编号
nodes_coupling=find_mode_node(x_min_P,x_max_P,y_min_TP,y_max_TP,z_max_P,z_max_P,node_corse);
Plot_scatter3(node_corse,nodes_coupling);
%% test phantom
nodes_phantom_corse=node_corse(nodes_phantom,:);
element_phantom_new=zeros(size(element_phantom_corse,1),4);
for i=1:size(element_phantom_corse,1)
    element_phantom_new(i,1)=find(nodes_phantom==element_phantom_corse(i,1));
    element_phantom_new(i,2)=find(nodes_phantom==element_phantom_corse(i,2));
    element_phantom_new(i,3)=find(nodes_phantom==element_phantom_corse(i,3));
    element_phantom_new(i,4)=find(nodes_phantom==element_phantom_corse(i,4));
end
figure(15),tetramesh(element_phantom_new,nodes_phantom_corse);
figure(16),tetramesh(element_phantom_corse,node_corse);
node_circle_corse=find_in_circle2(nodes_phantom_corse,center,r);
[element_circle_corse,element_back_corse]=TetraElementSelect(element_phantom_new,node_circle_corse);
figure(111),tetramesh(element_circle_corse,nodes_phantom_corse)
figure(211),tetramesh(element_back_corse,nodes_phantom_corse)
filename_Elemen4 = fullfile(parentPath, ['0715_exp3','_element_back_corse','.mat']); 
save(filename_Elemen4,'element_back_corse');
filename_Elemen4 = fullfile(parentPath, ['0715_exp3','_element_circle_corse','.mat']); 
save(filename_Elemen4,'element_circle_corse');
filename_Elemen4 = fullfile(parentPath, ['0715_exp3','_nodes_phantom_corse','.mat']); 
save(filename_Elemen4,'nodes_phantom_corse');
%% test TP
nodes_TP_new=zeros(size(nodes_TP,1),1);
nodes_TP_corse=node_corse(nodes_TP,:);
element_TP_new=zeros(size(element_TP_corse,1),4);
for i=1:size(element_TP_corse,1)
    element_TP_new(i,1)=find(nodes_TP==element_TP_corse(i,1));
    element_TP_new(i,2)=find(nodes_TP==element_TP_corse(i,2));
    element_TP_new(i,3)=find(nodes_TP==element_TP_corse(i,3));
    element_TP_new(i,4)=find(nodes_TP==element_TP_corse(i,4));
end
figure(17),tetramesh(element_TP_new,nodes_TP_corse);
figure(18),tetramesh(element_TP_corse,node_corse);

TP_fix_node=find_mode_node(x_min_TP,x_max_TP,y_min_TP,y_max_TP,z_max_TP,z_max_TP,nodes_TP_corse);
TP_move_node=find_mode_node(x_min_TP,x_max_TP,y_min_TP,y_max_TP,z_min_TP,z_min_TP,nodes_TP_corse);

nodes_TP_2D_new=find_mode_node(x_min_P,x_max_P,Y_center,Y_center,z_min_TP,z_min_TP,nodes_TP_corse);% 这里是只找到与之接触的点
Plot_scatter3(nodes_TP_corse,nodes_TP_2D_new);

Plot_scatter3(nodes_TP_corse,TP_fix_node);
Plot_scatter3(nodes_TP_corse,TP_move_node);
figure(100);
Plot_scatter3(nodes_TP_corse,nodes_TP_2D_new);
filename_Elemen3 = fullfile(parentPath, ['0715_exp3','_nodes_TP_2D_new','.mat']); 
save(filename_Elemen3,'nodes_TP_2D_new');

filename_Elemen2 = fullfile(parentPath, ['0715_exp3_','TP_fix_node','.mat']); 
save(filename_Elemen2,'TP_fix_node');

filename_Elemen3 = fullfile(parentPath, ['0715_exp3_','TP_move_node','.mat']); 
save(filename_Elemen3,'TP_move_node');


x_center_TP=(x_min_TP+x_max_TP)/2;
y_center_TP=Y_center;
z_center_TP=z_max_TP;
nodes_TP_center=find_mode_node(x_center_TP-4,x_center_TP,y_center_TP,y_center_TP,z_center_TP,z_center_TP,nodes_TP_corse);
filename_Elemen3 = fullfile(parentPath, ['0715_exp3_','nodes_TP_center','.mat']); 
save(filename_Elemen3,'nodes_TP_center');
%% nodes: TP couple with phantom
A=nodes_phantom_corse;
B=nodes_TP_corse;
[~, row_numbers] = ismember(A, B, 'rows');
j=1;
map_couple=[];
% 打印结果
for i = 1:size(A, 1)
    if row_numbers(i) > 0
        map_couple(j,1)=i;
        map_couple(j,2)=row_numbers(i);
        j=j+1;
    end
end
n_couple=size(map_couple,1);
figure(26),
scatter3(nodes_TP_corse(map_couple(:,2),1),nodes_TP_corse(map_couple(:,2),2),nodes_TP_corse(map_couple(:,2),3))
axis equal
figure(27),
scatter3(nodes_phantom_corse(map_couple(:,1),1),nodes_phantom_corse(map_couple(:,1),2),nodes_phantom_corse(map_couple(:,1),3))
axis equal
%% output 3D
% nodes_phantom_corse
% element_phantom_new
% nodes_TP_corse
% element_TP_new
% map_couple
filename_Elemen1 = fullfile(parentPath, ['0715_exp3','_nodes_phantom_corse','.mat']); 
save(filename_Elemen1,'nodes_phantom_corse');

filename_Elemen2 = fullfile(parentPath, ['0715_exp3','_element_phantom_new','.mat']); 
save(filename_Elemen2,'element_phantom_new');

filename_Elemen3 = fullfile(parentPath, ['0715_exp3','_nodes_TP_corse','.mat']); 
save(filename_Elemen3,'nodes_TP_corse');


filename_Elemen3 = fullfile(parentPath, ['0715_exp3','_nodes_TP_2D','.mat']); 
save(filename_Elemen3,'nodes_TP_2D');

filename_Elemen4 = fullfile(parentPath, ['0715_exp3','_element_TP_new','.mat']); 
save(filename_Elemen4,'element_TP_new');

filename_Elemen5 = fullfile(parentPath,[ '0715_exp3','_map_couple','.mat']); 
save(filename_Elemen5,'map_couple');

%% 2D有限元 这里要明确的一个事情是：所有求取的节点编号，是nodes_phantom_corse下的编号，nodes_phantom_corse是nodes_corse的子集
% 整个截面 element_phantom_new
FaceNode_2D=Find_2D_node_2(Y_center,z_min_P,z_max_P,nodes_phantom_corse);% 2D有限元的截面结点
Face_Tri=Tetra2TriSelect(element_phantom_new,FaceNode_2D);
Face_Tri=OmitRepeatElement(Face_Tri);
[results,Face_Tri]=checkTriDirection_new(Face_Tri,nodes_phantom_corse);
figure,trimesh(Face_Tri,nodes_phantom_corse(:,1),nodes_phantom_corse(:,2),nodes_phantom_corse(:,3))
axis equal
filename_Elemen1 = fullfile(parentPath, '0715_exp3_Face_Tri.mat'); 
save(filename_Elemen1,'Face_Tri');

% 中间圆形区域
P_center=[center(1) Y_center center(2)];
n_face2D=size(FaceNode_2D,1);
Positions=zeros(n_face2D,3);
for i=1:n_face2D
    Positions(i,:)=nodes_phantom_corse(FaceNode_2D(i),:);
end
distances = sqrt(sum((Positions - P_center).^2, 2));
Face_node_circle_temp = find(distances <= r);

Face_node_circle=FaceNode_2D(Face_node_circle_temp);
% Face_Tri1=Tetra2TriSelect(element_corse,FaceNode_2D);
Face_Tri=Tetra2TriSelect(element_phantom_new,FaceNode_2D);
[result3,Face_Tri_new]=checkTriDirection_new(Face_Tri,nodes_phantom_corse);
[Face_tri_circle,Face_tri_rest]=TriElementSelect(Face_Tri_new,Face_node_circle);
Face_tri_circle=OmitRepeatElement(Face_tri_circle);
Face_tri_rest=OmitRepeatElement(Face_tri_rest);
figure,trimesh(Face_tri_circle,nodes_phantom_corse(:,1),nodes_phantom_corse(:,2),nodes_phantom_corse(:,3),'FaceColor','b');
hold on
trimesh(Face_tri_rest,nodes_phantom_corse(:,1),nodes_phantom_corse(:,2),nodes_phantom_corse(:,3),'FaceColor','y');
hold off

%% 2D和3D有限元一些特殊的节点寻找
FaceNode_US_3D=find_face_node(z_max_P,Y_center-d/2,Y_center+d/2,nodes_phantom_corse);% 超声探头的接触区域
FaceNode_up_3D=find_face_node2(z_max_P,nodes_phantom_corse);% 接近圆柱的面，超声探头接触面
FaceNode_down_3D=find_face_node2(z_min_P,nodes_phantom_corse);% 远离圆柱的面，位移移动面

RegionNode_US=find_ROI_node(x_min_rio,x_max_rio,Y_center,z_min_rio,z_max_rio,nodes_phantom_corse); % 目标配准区域的点
[Line_node_up,Line_node_down]=Find_2line_Node(nodes_phantom_corse,z_max_P,z_min_P,Y_center); % 2D 有限元上下边的点
plot_nodes(FaceNode_US_3D,nodes_phantom_corse,50);
plot_nodes(FaceNode_up_3D,nodes_phantom_corse,60);%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plot_nodes(FaceNode_down_3D,nodes_phantom_corse,7);
plot_nodes(Line_node_up,nodes_phantom_corse,8);
plot_nodes(Line_node_down,nodes_phantom_corse,9);
plot_nodes(RegionNode_US,nodes_phantom_corse,10);
%% 输出节点
filename_Elemen1 = fullfile(parentPath, '0715_exp3_FaceNode_US_3D.mat'); 
save(filename_Elemen1,'FaceNode_US_3D');
filename_Elemen2 = fullfile(parentPath, '0715_exp3_FaceNode_up_3D.mat');  
save(filename_Elemen2,'FaceNode_up_3D');
filename_Elemen3 = fullfile(parentPath, '0715_exp3_FaceNode_down_3D.mat'); 
save(filename_Elemen3,'FaceNode_down_3D');
filename_Elemen4 = fullfile(parentPath, '0715_exp3_FaceNode_2D.mat'); 
save(filename_Elemen4,'FaceNode_2D');
filename_Elemen5 = fullfile(parentPath, '0715_exp3_RegionNode_US.mat'); 
save(filename_Elemen5,'RegionNode_US');
filename_Line = fullfile(parentPath, '0715_exp3_Line_node_up.mat'); 
save(filename_Line,'Line_node_up');
filename_Line2 = fullfile(parentPath, '0715_exp3_Line_node_down.mat'); 
save(filename_Line2,'Line_node_down');
%% 输出单元
filename_Elemen1 = fullfile(parentPath, '0715_exp3_Face_tri_circle.mat'); 
save(filename_Elemen1,'Face_tri_circle');
filename_Elemen1 = fullfile(parentPath, '0715_exp3_Face_tri_rest.mat'); 
save(filename_Elemen1,'Face_tri_rest');
filename_Elemen1 = fullfile(parentPath, '0715_exp3_node_corse.mat'); 
save(filename_Elemen1,'node_corse');