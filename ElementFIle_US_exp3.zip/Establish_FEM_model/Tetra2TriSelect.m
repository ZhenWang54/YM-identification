function [Tnew]=Tetra2TriSelect(T,node_ID)

Tri_pool=ismember(T,node_ID);
sign_Tri=sign(double(Tri_pool));
Tri_pool=sum(Tri_pool,2);%行相加
Tri_ID=find(Tri_pool==3);%我理解的是找出某个element，完全包含这三个节点组成的面
Tnew=T(Tri_ID,:).*sign_Tri(Tri_ID,:);
Tnew=Tnew';
Tnew(Tnew==0)=[];
Tnew=reshape(Tnew,3,numel(Tnew)/3);
Tnew=Tnew';



% ID_all=1:length(Tri_pool);
% ID_res=setxor(ID_all,Tri_ID);
% T_res=T(ID_res,:);