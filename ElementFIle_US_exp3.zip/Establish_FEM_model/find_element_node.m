function element_node=find_element_node(xmin,xmax,Node_all)
x=Node_all(:,1);
element_node=find(x<=xmax & x>=xmin);
end