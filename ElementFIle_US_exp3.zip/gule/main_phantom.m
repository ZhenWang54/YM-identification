% Please cite the following two papers if you are using this code or the
% accompanying RF-data 

% [1] Rivaz, H., Boctor, E., Choti, M., Hager, G., Real-Time Regularized
% Ultrasound Elastography�, IEEE Trans. Medical Imaging, April 2011, 
% vol. 30 pp 928-945
% [2] Hashemi, H., Rivaz, H., Global Time-Delay Estimation in Ultrasound
% Elastography, IEEE Trans. UFFC, 2017

% Regularization coefficients:
% alfa1 = axial continuity in a A-line
% alfa2 = axial continuity at the neighboring samples
% beta1 = lateral continuity in a A-line
% beta2 = lateral continuity at the neighboring samples
% The best set is 5, 1, 5, 1 or if you need smoother displacements, put
% them 20, 1, 20, 1 respectively.

% There are other parameters. The code is not very sensitive to these
% parameters, but if you want the best result, it is recommended to set
% them carefully:

% IRF: the range of variation of axial displacement. set it to:
% [-a 0] if compression
% [0 b] if extension
% [-a b] if not sure

% IA: the range of variation of lateral displacement. set it to:
% [-a 0] if moved to the left
% [0 b] if moved to the right
% [-a b] if not sure

% midA: the seed RF-line where the displacement calculation starts from

clear
% ------------------------------------------------------- %
% -------------- loading simulation RF Data ------------- %
% ------------------------------------------------------- %
% load 'rf01.mat'
% Im1 = RfDataDouble(1:1700,:);
% maxIm = max(Im1(:));
% Im1 = Im1/maxIm;
% load 'rf03.mat'
% Im2 = RfDataDouble(1:1700,:);
% Im2 = Im2/maxIm;
%%
close all
clear
clc
filepath_befroe = ['F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\US_data_20230710\temp_data\80/Resize_before_1.5mm.bmp'];
filepath_after = ['F:\OneDrive - zju.edu.cn\xutian\XTConferenceIdea\ElementFIle_US\US_data_20230710\temp_data\80/Resize_after_1.5mm.bmp'];
% imtest=imread('cut_before_resize.bmp');
imtest=imread(filepath_befroe);
grayImage = rgb2gray(imtest);
Im1 = im2double(grayImage);
% imtest=imread('cut_after_resize.bmp');
imtest=imread(filepath_after);
grayImage = rgb2gray(imtest);
Im2 = im2double(grayImage);

%%




% ------------------------------------------------------- %
% ------------- set See_B_mode to see B-mode ------------ %
% ------------------------------------------------------- %
See_B_mode = 1;
if See_B_mode
    BMODE1 = log(abs(hilbert(Im1))+.01);
    figure,  imagesc(BMODE1);colormap(gray), colorbar
    BMODE2 = log(abs(hilbert(Im2))+.01);
    figure, imagesc(BMODE2);colormap(gray), colorbar
end

See_B_mode = 1;
if See_B_mode
    BMODE1 = log(abs((Im1))+.01);
    figure,  imagesc(BMODE1);colormap(gray), colorbar
    BMODE2 = log(abs((Im2))+.01);
    figure, imagesc(BMODE2);colormap(gray), colorbar
end

% ------------------------------------------------------- %
% ---------- initial displacements using 2D DPAM -------- %
% ------------------------------------------------------- %
IRF = [-100 0]; % Maximum allowed disparity in axial D
IA = [-4 4]; % Maximum allowed disparity in lateral D
midA = 50;
alfa = 5; %axial regularization
beta = 10; %lateral regularization
gamma = 0.005; %lateral regularization 
T = .2; % threshold for IRLS
xx = 1; % to compensate for attenuation
alfa_DP = 0.2; % DP regularization weight
tic
[ax0, lat0, ~] = RCF_AM2D(Im1, Im2, IRF, IA, midA, alfa_DP, alfa, beta, gamma, T, xx);
% the disp. of the first 40 and last 40 samples is not calculated in AM2D: 
% the disp. of the first 10 and last 10 A-lines is not calculated in AM2D:
% 原来的代码是把图像的竖直方向上下各减去了40个像素1700-80=1620，左右也各减去了15个像素。
ax0 = ax0(41:end-40, 16:end-15);
lat0 = lat0(41:end-40, 16:end-15);
Im1 = Im1(41:end-40, 16:end-15);
Im2 = Im2(41:end-40, 16:end-15);
% 我觉得不能减去这些
% ------------------------------------------------------- %
% ---------- accurate displacements using GLUE ---------- %
% ------------------------------------------------------- %
alfa1 = 5 ; % regularization coefficients
alfa2 = 1 ;
beta1 = 5 ; 
beta2 = 1 ;


[Axial, Lateral] = GLUE (ax0, lat0, Im1, Im2, alfa1, alfa2, beta1, beta2);
toc
figure, imagesc(Axial), colorbar, title('axial displacement'), colormap(hot);
figure, imagesc(Lateral), colorbar, title('lateral displacement'), colormap(hot);

% ---------------------------------------------------- %
% ------------ Calculating Strain from Disp ---------- %
% ---------------------------------------------------- %
xRat = (40.8-2.5)/508;
yRat = 42.95/2233;
% axial strain
wDIff = 93; % window length of the differentiation kernel
strainA = LSQ(Axial(101:end-100,51:end-50),wDIff);
strainA = -strainA((wDIff+1)/2:end-(wDIff-1)/2,:);
strainA(strainA>.1) = .1;
strainA(strainA<2e-2) = 2e-2;
startA = 1; endA = size(strainA,2);
startRF = 1; endRF = size(strainA,1); 
figure; imagesc([0 xRat*(endA-startA)],yRat*[startRF endRF],strainA);
colorbar; colormap(gray);xlabel('width (mm)'); ylabel('depth (mm)');

% lateral strain:
wDIff = 23; % window length of the differentiation kernel
strainL = LSQ(Lateral(147:end-146,5:end-4)',wDIff);
strainL = strainL((wDIff+70+1)/2:end-(wDIff+70-1)/2,:)';
strainL(strainL<-0.002) = -0.002;
strainL(strainL>.043) = .043;
figure; imagesc([0 xRat*(endA-startA)],yRat*[startRF endRF],strainL);
colorbar; colormap(gray);xlabel('width (mm)'); ylabel('depth (mm)');


save('Axial_2mm.mat','Axial');
save('Lateral_2mm.mat','Lateral')

