% Please cite the following two papers if you are using this code or the
% accompanying RF-data 

% [1] Rivaz, H., Boctor, E., Choti, M., Hager, G., Real-Time Regularized
% Ultrasound Elastography�, IEEE Trans. Medical Imaging, April 2011, 
% vol. 30 pp 928-945
% [2] Hashemi, H., Rivaz, H., Global Time-Delay Estimation in Ultrasound
% Elastography, IEEE Trans. UFFC, 2017

% Regularization coefficients:
% alfa1 = axial continuity in a A-line
% alfa2 = axial continuity at the neighboring samples
% beta1 = lateral continuity in a A-line
% beta2 = lateral continuity at the neighboring samples
% The best set is 5, 1, 5, 1 or if you need smoother displacements, put
% them 20, 1, 20, 1 respectively.

% There are other parameters. The code is not very sensitive to these
% parameters, but if you want the best result, it is recommended to set
% them carefully:

% IRF: the range of variation of axial displacement. set it to:
% [-a 0] if compression
% [0 b] if extension
% [-a b] if not sure

% IA: the range of variation of lateral displacement. set it to:
% [-a 0] if moved to the left
% [0 b] if moved to the right
% [-a b] if not sure

% midA: the seed RF-line where the displacement calculation starts from

clear
% ------------------------------------------------------- %
% -------------- loading simulation RF Data ------------- %
% ------------------------------------------------------- %
f_sample = 40e6; %  Sampling frequency [Hz]
c_sound = 1540e3; % mm/s
im_width = 20; % mm
load 'Im2_with_tstart.mat'
Im2 = Im0( 5*2*round(f_sample/c_sound):25*2*round(f_sample/c_sound) , : );
maxIm = max(Im2(:));
Im2 = Im2/maxIm;
load 'Im1_with_tstart.mat'
Im1 =Im01( 5*2*round(f_sample/c_sound):25*2*round(f_sample/c_sound) , : );
Im1 = Im1/maxIm;
% ------------------------------------------------------- %
% ------------- set See_B_mode to see B-mode ------------ %
% ------------------------------------------------------- %
See_B_mode = 0;
if See_B_mode
    BMODE1 = log(abs(hilbert(Im1))+.01);
    figure,  imagesc(BMODE1);colormap(gray), colorbar
    BMODE2 = log(abs(hilbert(Im2))+.01);
    figure, imagesc(BMODE2);colormap(gray), colorbar
end
% ------------------------------------------------------- %
% ---------- initial displacements using 2D DP ---------- %
% ------------------------------------------------------- %
IRF = [-30 0];
IA = [-1 1]; %Maximum allowed disparity in lateral D
alfa_DP = 0.2; % DP regularization weight
tic
[ax0, lat0] = DP(Im1, Im2, IRF, IA, alfa_DP);
% the disp. of the first 40 and last 40 samples is not calculated in AM2D: 
% the disp. of the first 10 and last 10 A-lines is not calculated in AM2D:
ax0 = ax0(41:end-40, 16:end-15);
lat0 = lat0(41:end-40, 16:end-15);
Im1 = Im1(41:end-40, 16:end-15);
Im2 = Im2(41:end-40, 16:end-15);

% ------------------------------------------------------- %
% ---------- accurate displacements using GLUE ---------- %
% ------------------------------------------------------- %
alfa1 = 5 ; % regularization coefficients
alfa2 = 1 ;
beta1 = 5 ; 
beta2 = 1 ;
[Axial, Lateral] = GLUE (ax0, lat0, Im1, Im2, alfa1, alfa2, beta1, beta2);
toc
figure, imagesc(Axial), colorbar, title('axial displacement'), colormap(hot);
figure, imagesc(Lateral(60:600-40, :)), colorbar, title('lateral displacement'), colormap(hot);

% In our lateral data, the corresponding ROI to axial is shown (line above)
% and will be used for lateral strain calculation.

% ---------------------------------------------------- %
% ------------ Calculating Strain from Disp ---------- %
% ---------------------------------------------------- %

% axial strain:
wDIff = 143; % window length of the differentiation kernel
[strain1] = LSQ(Axial,wDIff);
strain1 = strain1((wDIff+1)/2:end-(wDIff-1)/2,:);
strain1(strain1>0) = 0;
strain1(strain1<-.03) = -.03;
figure,  imagesc([0 20],[0 20],strain1);
colormap(gray), colorbar, title('axial strain');
xlabel('width (mm)'); ylabel('depth (mm)');


% lateral strain
wDIff = 93; % window length of the differentiation kernel
[strain2] = LSQ(-Lateral(60:600-40, :)',wDIff); 
strain2 = strain2((wDIff+1)/2:end-(wDIff-1)/2,:)';
strain2(strain2>0) = 0;
strain2(strain2<-.03) = -.03;
figure, imagesc([0 20],[0 20],strain2);
colormap(gray), colorbar, title('lateral strain');
xlabel('width (mm)'); ylabel('depth (mm)');
