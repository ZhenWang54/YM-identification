Run simulation.m file for testing the simulation data.
Run the phantom.m file for testing the phantom data.

Please cite the following two papers if you use this code:
H. Hashemi, H. Rivaz, Global Time-Delay Estimation in Ultrasound Elastography, IEEE Trans. Ultrasonics Ferroelectrics Frequency Control (TUFFC), Oct. 2017, vol 64, pp 1625-1636 

H. Rivaz, Boctor, E., Choti, M., Hager, G., Real-Time Regularized Ultrasound Elastography, IEEE Trans. Medical Imaging, April 2011, vol. 30 pp 928-945

Thanks to Md. Ashikuzzaman (MASc student at Concordia University's IMPACT laboratory) for writing a faster interpolation method in this implementation.