function U_3D=FUN_FEM_3D_forward_Phantom_disp(alpha,scale)
load 80_element_back_corse.mat
load 80_element_circle_corse.mat
load 80_element_corse.mat
load 80_node_corse.mat
load 80_DKKG_cylinder.mat
load 80_DKKG_block.mat
load 80_FaceNode_up_3D.mat
load 80_FaceNode_down_3D.mat
load 80_FaceNode_US_3D.mat
NU=0.49;

nnode=size(node_corse,1);
Lf=cal_ob_map(nnode,FaceNode_US_3D);% 超声固定边界
nKB_sub1=size(Lf,1);

Lmx=cal_ob_map_3D_wz_sigle(nnode,FaceNode_down_3D,1);% 底部固定边界
Lmy=cal_ob_map_3D_wz_sigle(nnode,FaceNode_down_3D,2);% 底部固定边界
Lmz=cal_ob_map_3D_wz_sigle(nnode,FaceNode_down_3D,3);% 底部移动边界

Lm_xyz=[Lmx;Lmy;Lmz];
Lk_all=[Lf;Lm_xyz];
nKB_all=size(Lk_all,1);

nKB_sub2x=size(Lmx,1);
nKB_sub2y=size(Lmy,1);
nKB_sub2z=size(Lmz,1);

E=1e4;
KKG=E*(alpha*DKKG_cylinder+DKKG_block);
% r = sprank(KKG)
MB_F=zeros(3*nnode,1);%% 力载荷

KB_Uus=zeros(nKB_sub1,1);%% 固定边界约束
KB_Ux=zeros(nKB_sub2x,1);%% 固定边界约束
KB_Uy=zeros(nKB_sub2y,1);%% 固定边界约束

KM_U=ones(nKB_sub2z,1)*scale;%% 移动边界约束
KF_U=[KB_Uus;KB_Ux;KB_Uy];

%U2 (Measured Force)
Kall=sparse(3*nnode+nKB_all,3*nnode+nKB_all);
Kall(1:3*nnode,1:3*nnode)=KKG;
Kall(3*nnode+1:3*nnode+nKB_all,1:3*nnode)=Lk_all;
Kall(1:3*nnode,3*nnode+1:3*nnode+nKB_all)=Lk_all';

%Pesudo Force
PFall=[MB_F;KF_U;KM_U];
%Pesudo Displacement
U3D_temp=Kall\PFall;
U_3D=U3D_temp(1:3*nnode);
% plot
% plotFEMtetra(node_corse,element_back_corse,element_circle_corse,U_3D)
% title(['sidefix_x bottomfix_yz 3D deform, alpha=',num2str(alpha)]);
end