%% 这个是专门针对贴片的位移场计算函数，且位移场是对应假体和贴片一起的图像和FEM的情况
function displacements_FEM_Z=FUN_disp_TP(FilePath_before,FilePath_after,scale_X,scale_Y,T_tran,P_FEM_center,nodes_TP_corse,nodes_TP_2D,Zmax_TP)
    [image_cut_before_TP,rect,image_resize_before,image_resize_after]=FUN_Image_preprocess_TPandPhantom(FilePath_before,FilePath_after);
    [Axial, Lateral]=FUN_glue2(image_resize_before,image_resize_after);
    disp('选取裁切图像中贴片中间底部的位置');
    P_middle_cut=FUN_get_center_node(image_cut_before_TP);% 选取裁切图像中标定的位置，这里采用贴片顶部中心点进行配准
    disp(P_middle_cut);
    scale_reviseX=rect(3)/508;%表示裁切的图像到US变换的横向变换比例
    scale_reviseY=rect(4)/1700;%表示裁切的图像到US变换的纵向变换比例
    scale_revise=[scale_reviseX,scale_reviseY];
    scale_US_FEM=[scale_reviseX/scale_X,scale_reviseY/scale_Y];% 这里表示超声位移场中的像素坐标与实际mm坐标之间的尺度变换
    P_middle_US=P_middle_cut./scale_revise;% 超声初始图片里，贴片中心处顶部的点的位置
    % P_center_US=[254,868];
    P_middle_Axial=P_middle_US+T_tran;% 超声位移场Axial中，圆心的位置（有一个裁切）  
    P_middle_FEM_to_Axial=P_FEM_center./scale_US_FEM;% Axial下的圆心位置
    T_axial_FEM=P_middle_Axial-P_middle_FEM_to_Axial;
%% 计算有限元网格结点对应的位移场
Position_FEM(:,1)=nodes_TP_corse(nodes_TP_2D,1);
Position_FEM(:,2)=nodes_TP_corse(nodes_TP_2D,3);
scatter(Position_FEM(:,1),Position_FEM(:,2));
Position_FEM_rot(:,1)=Position_FEM(:,1);
Position_FEM_rot(:,2)=Zmax_TP-Position_FEM(:,2);
[n_ROI,~]=size(Position_FEM);
P_FEM_to_Axial=zeros(n_ROI,2);
displacements=zeros(n_ROI,2);
for i=1:n_ROI
    P_FEM_to_Axial(i,:)=Position_FEM_rot(i,:)./scale_US_FEM+T_axial_FEM;   % 有限元结点对应的axial下的像素坐标
    P_FEM_to_Axial(i,:)=round(P_FEM_to_Axial(i,:)); % 取整后的像素坐标
    y = P_FEM_to_Axial(i, 1);% 获得目标点在超声图像坐标系下的横纵坐标值
    x = P_FEM_to_Axial(i, 2);    
    displacementX= Lateral(x,y);
    displacementY= -Axial(x,y);
    displacements(i, :) = [displacementX, displacementY];
    % 注意，Axial里面的位移场方向是相对于Axial坐标系的，所以Axial的方向应该变换一下
end
%%
    displacements_=displacements.*scale_US_FEM;  
    displacements2=displacements_';
    displacements_FEM_Z=displacements2(:);%displacements是一个2N的一维向量，对应于2D截面的位移场；   
%%
figure, imagesc(Axial), colorbar, title('axial displacement'), colormap(hot);
hold on
scatter(P_FEM_to_Axial(:,1),P_FEM_to_Axial(:,2),'k'); % 显示有限元的节点
P_middle_Axial=P_middle_Axial';
P_middle_FEM_to_Axial=P_middle_FEM_to_Axial';
scatter(P_middle_FEM_to_Axial(1),P_middle_FEM_to_Axial(2),'+g');% +号表示有限元的中心点（没平移变换之前的）
scatter(P_middle_Axial(1),P_middle_Axial(2),'*g'); % 手动选择的超声图像中的点
end