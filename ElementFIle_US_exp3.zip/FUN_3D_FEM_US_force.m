function U_3D=FUN_3D_FEM_US_force(alpha,FFG_contact,expID)
% Forcedisp_Phantom_3D_z是指的强制移动点的z方向位移向量
load(fullfile(['0715_exp',num2str(expID),'_element_back_corse.mat']))
load(fullfile(['0715_exp',num2str(expID),'_element_circle_corse.mat']))
load(fullfile(['0715_exp',num2str(expID),'_element_phantom_new.mat']))% 这个是2D超声切面对应的接触面节点
load(fullfile(['0715_exp',num2str(expID),'_nodes_phantom_corse.mat']))
load(fullfile(['0715_exp',num2str(expID),'_DKKG_cylinder.mat']))
load(fullfile(['0715_exp',num2str(expID),'_DKKG_block.mat']))
load(fullfile(['0715_exp',num2str(expID),'_FaceNode_down_3D.mat']))
load(fullfile(['0715_exp',num2str(expID),'_FaceNode_US_3D.mat']))

NU=0.49;
node_corse=nodes_phantom_corse;
nnode=size(node_corse,1);

Lf=cal_ob_map(nnode,FaceNode_down_3D);% 底部固定边界
nKB_sub1=size(Lf,1);
Lk_all=Lf;
nKB_all=size(Lk_all,1);
E=15000/1e6; 
KKG=E*(alpha*DKKG_cylinder+DKKG_block);
MB_F=FFG_contact;%% 力载荷
KF_U=zeros(nKB_sub1,1);%% 固定边界约束
%U2 (Measured Force)
Kall=sparse(3*nnode+nKB_all,3*nnode+nKB_all);
Kall(1:3*nnode,1:3*nnode)=KKG;
Kall(3*nnode+1:3*nnode+nKB_all,1:3*nnode)=Lk_all;
Kall(1:3*nnode,3*nnode+1:3*nnode+nKB_all)=Lk_all';

%Pesudo Force
PFall=[MB_F;KF_U];
%Pesudo Displacement
U3D_temp=Kall\PFall;
U_3D=U3D_temp(1:3*nnode);
% plot
% plotFEMtetra(node_corse,element_back_corse,element_circle_corse,U_3D)
% title(['sidefix_x bottomfix_yz 3D deform, alpha=',num2str(alpha)]);
end