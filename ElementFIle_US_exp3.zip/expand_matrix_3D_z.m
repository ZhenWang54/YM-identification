function A=expand_matrix_3D_z(B)
    Matrix_z=[0 0 0;0 0 0; 0 0 1];
   A=repelem(B,3,3).*repmat(Matrix_z,size(B,1),size(B,2));
end