% % 根据强制位移，仿真获得2D和3D的比杨氏模块数据集
clear;
clc;
close all;
load 0715_exp3_U2_TP_Disp.mat %% 第偶数个是z方向的位移
% load 0715_exp3_nodes_TP_DISP.mat
load 0715_exp3_Forcedisp_Phantom_3D.mat
load 0715_exp3_Forcedisp_Phantom_2D.mat

std_error_set=[];
t_best_set=[];
iter=0;
alphamax=9;
alphamin=1;
alpha_step=0.5;
alpha2D_set=zeros((alphamax-alphamin)/alpha_step+1,1);
alpha3D_set=zeros((alphamax-alphamin)/alpha_step+1,1);
alpha2D_set_test=zeros((alphamax-alphamin)/alpha_step+1,1);
alpha3D_set_test=zeros((alphamax-alphamin)/alpha_step+1,1);
Fig_N=10; % 第10张图
expID=3;
%% 求解对应的2D比杨氏模量
Forcedisp_Phantom_3D_z=Forcedisp_Phantom_3D(:,3);
for alpha_3D=alphamin:alpha_step:alphamax
    iter=iter+1;
%     UUG_3D=FUN_3D_FEM_US(alpha_3D,nodes_TP_DISP,expID);%% 计算3D位移场
    UUG_3D=FUN_3D_FEM_US(alpha_3D,Forcedisp_Phantom_3D_z,expID);%% 计算3D位移场
    save('0715_exp3_UUG_3D.mat ','UUG_3D');
    alpha_2D=Tri_alpha_tool_US_disp(1,0.1,200);
    alpha2D_set(iter)=alpha_2D;
    alpha3D_set(iter)=alpha_3D;
end

alphamin_test=alphamin+0.1;
alphamax_test=alphamax+0.1;
iter=0;
for alpha_3D=alphamin_test:alpha_step:alphamax_test
    iter=iter+1;
    UUG_3D=FUN_3D_FEM_US(alpha_3D,Forcedisp_Phantom_3D_z,expID);%% 计算3D位移场
    save('0715_exp3_UUG_3D.mat ','UUG_3D');
    alpha_2D=Tri_alpha_tool_US_disp(1,0.1,200);
    alpha2D_set_test(iter)=alpha_2D;
    alpha3D_set_test(iter)=alpha_3D;
end
%%
save('0715_exp3_alpha3D_set.mat','alpha3D_set');
save('0715_exp3_alpha2D_set.mat','alpha2D_set');
save('0715_exp3_alpha3D_set_test.mat','alpha3D_set_test');
save('0715_exp3_alpha2D_set_test.mat','alpha2D_set_test');
%% Tri_alpha_tool_simulate_disp
% load alpha_2D_US.mat
% alpha_2D_US=0.3934;
%%
load('0715_exp3_alpha3D_set.mat');
load('0715_exp3_alpha2D_set.mat');
load('0715_exp3_alpha3D_set_test.mat');
load('0715_exp3_alpha2D_set_test.mat');
tic
Fig_N=100;
alpha_2D_US=Tri_alpha_tool_simulate_disp(1,0.1,100);
toc
alpha_3D_US=Plot_Kriging_US(alpha3D_set,alpha2D_set,alpha3D_set_test,alpha2D_set_test,Fig_N,alpha_2D_US)
% disp(['Kriging 预测3D杨氏模量值为：',num2str(alpha_3D_US),' 计算的2D的值为：',num2str(alpha_2D_US),'真实的值为：4.04']);