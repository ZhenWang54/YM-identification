% 计算贴片的3D正向模型，基于位移边界约束情况，计算接触面节点对应的接触力
%% Map_TP_ID是与假体接触节点编号；在这里用作移动位移约束
%% expID是实验编号
%% E_modulus是真实贴片的杨氏模量
%% FUN_FEM_3D_forward_TP_2 和FUN_FEM_3D_forward_TP的区别在于贴片的边界约束条件由全固定约束修改为了z方向固定约束，接触了限制条件
function Force_contact=FUN_FEM_3D_forward_TP_2(expID,E_modulus,nodes_TP_DISP,Map_TP_ID)
load(fullfile(['0715_exp',num2str(expID),'_element_TP_new.mat']))
load(fullfile(['0715_exp',num2str(expID),'_nodes_TP_corse.mat']))
load(fullfile(['0715_exp',num2str(expID),'_nodes_TP_2D.mat']))% 这个是2D超声切面对应的接触面节点
load(fullfile(['0715_exp',num2str(expID),'_TP_fix_node.mat']))
load(fullfile(['0715_exp',num2str(expID),'_TP_move_node.mat']))
load(fullfile(['0715_exp',num2str(expID),'_nodes_TP_2D_new.mat']))
% load(fullfile(['0715_exp',num2str(expID),'_KKG_TP.mat']))
load(fullfile(['0715_exp',num2str(expID),'_nodes_TP_center.mat']))

NU=0.49;
node_corse=nodes_TP_corse;
element_corse=element_TP_new;
scatter3(node_corse(:,1),node_corse(:,2),node_corse(:,3));

%%
% tic;
KKG_TP=E_modulus*Compute_DKKG_Tetra(node_corse,element_corse,NU);
KKG=KKG_TP;
nnode=size(node_corse,1);
% DDKG_block_name=fullfile(['0715_exp',num2str(expID),'_KKG_TP.mat']);
% save(DDKG_block_name,'KKG_TP')
% r = sprank(KKG);
% a=diag(full(KKG));
% disp(r);
MB_F=zeros(3*nnode,1);
Constrain_fix=TP_fix_node;
% Constrain_move=TP_move_node;
Constrain_move=Map_TP_ID;
% Plot_scatter3(node_corse,Constrain_move)
Lk_move=cal_ob_map_3D_wz_sigle(nnode,Constrain_move,3);
Lk_fix=cal_ob_map_3D_wz_sigle(nnode,Constrain_fix,3);

Lk_fix2=cal_ob_map_3D_wz_sigle(nnode,nodes_TP_center,1);
Lk_fix3=cal_ob_map_3D_wz_sigle(nnode,nodes_TP_center,2);
Lk_fix_all=[Lk_fix;Lk_fix2;Lk_fix3];
% Lk_fix=cal_ob_map(nnode,Constrain_fix);
Lk_all=[Lk_move;Lk_fix_all];
nKB=size(Lk_all,1);
nKB1=size(Lk_move,1);
nKB2=size(Lk_fix_all,1);
KB_U1=nodes_TP_DISP(:,3); %% 移动约束，赋值为
KB_U2=zeros(nKB2,1); %% 固定约束，赋值为0
KB_U=[KB_U1;KB_U2];
%U2 (Measured Force)
Kall_U2=sparse(3*nnode+nKB,3*nnode+nKB);
Kall_U2(1:3*nnode,1:3*nnode)=KKG;
Kall_U2(3*nnode+1:3*nnode+nKB,1:3*nnode)=Lk_all;
Kall_U2(1:3*nnode,3*nnode+1:3*nnode+nKB)=Lk_all';
%Pesudo Force
PFall_U2=[MB_F;KB_U];
%Pesudo Displacement
PUall_U2=Kall_U2\PFall_U2;

% Force_contact=PUall_U2(3*TP_move_node);%% 这里是输出接触点的力。
Force_contact=PUall_U2(1+3*nnode:3*nnode+nKB1); %% 这里是输出接触点的力。
U2=PUall_U2(1:3*nnode);
UUG=U2;
A=reshape(UUG,3,length(UUG)/3);
A=A';
%%
nodenew=node_corse+A;
figure,
tetramesh(element_TP_new,nodenew,'FaceAlpha',0.7,'FaceColor','y','EdgeAlpha',0.7);
figure,
tetramesh(element_TP_new,node_corse,'FaceAlpha',0.7,'FaceColor','y','EdgeAlpha',0.7);
% plotFEMtetra(node_corse,element_back_corse,element_circle_corse,U2)
% title(['sidefix_x bottomfix_yz 3D deform, alpha=',num2str(alpha)]);


