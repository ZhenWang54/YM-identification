function A=expand_matrix_3D(B)
   A=repelem(B,3,3).*repmat(eye(3),size(B,1),size(B,2));