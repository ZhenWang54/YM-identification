function DKKG=Compute_DKKG_Tri_yz(node,node_ID,element,NU,t,p)
if nargin<6
    p=1;
end



%确定节点、单元个数
% [nnode,~]=size(node);
nnode=length(node_ID);

%预先设定总体刚度矩阵、节点力向量、节点约束
%针对三维问题
DKKG=zeros(2*nnode);

%StressNode=zeros(nnode,6);
% k=zeros(6,6); % 单元刚度矩阵


%使用sparse矩阵可以加速运算！！提升10倍速以上
DKKG=sparse(DKKG);

%单元循环形成总体刚度矩阵
for i=1:size(element,1)
    
% k=LinearTriangleElementStiffness(1,NU,t,node(element(i,1),1),node(element(i,1),3) ,node(element(i,2),1),...
%     node(element(i,2),3),node(element(i,3),1),node(element(i,3),3),p);
k=LinearTriangleElementStiffness(1,NU,t,node(element(i,1),2),node(element(i,1),3) ,node(element(i,2),2),...
    node(element(i,2),3),node(element(i,3),2),node(element(i,3),3),p);

ID1=find(node_ID==element(i,1));
ID2=find(node_ID==element(i,2));
ID3=find(node_ID==element(i,3));

% DKKG =LinearTriangleAssemble(DKKG,k,element(i,1),element(i,2),element(i,3));
DKKG =LinearTriangleAssemble(DKKG,k,ID1,ID2,ID3);
end