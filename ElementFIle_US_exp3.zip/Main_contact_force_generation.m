%% 根据贴片计算的超声图像计算对应的三维情况的压力；运行这个程序之前，需要先运行US_disp_TP_Phantom.进行目标位移场的获取
%% 加载文件初始化
% clear;
% clc;
% close all;
load 0715_exp2_nodes_phantom_corse.mat
load 0715_exp2_map_couple.mat %% 这个couple对应的是三维体，两个体交界面处共用的节点各自编号，
load 0715_exp2_nodes_TP_corse.mat
load 0715_exp2_node_corse.mat

load 0715_exp2_nodes_TP_2D_new.mat %% 对应贴片在超声图像2D下与假体接触的点,
load 0715_exp2_U2_TP_Disp.mat %% 第偶数个是z方向的位移
load 0715_exp2_RegionNode_US.mat
load 0715_exp2_U2_real_Local.mat
expID=2;
% E_modulus_TP=37000/1e6; % 这里杨氏模量单位是N/(mm^2);
E_modulus_TP6=23000/1e6; % 这里杨氏模量单位是N/(mm^2);
coefficient_map_Disp=1;
coefficient_all_disp=1;
coefficient_aphantom_disp=1;
% coefficient_all_disp=0.8;
%% 根据中间的点位移计算整个贴片底面的位移
Map_TP_ID=map_couple(:,2);
Map_Phantom_ID=map_couple(:,1);
% Plot_scatter3(nodes_TP_corse,Map_TP_ID);
% Plot_scatter3(nodes_phantom_corse,Map_Phantom_ID);
node_orign_ID=nodes_TP_2D_new;
nn_TP_disp=size(U2_TP_Disp,1)/2;
node_orign_add=zeros(nn_TP_disp,1);
for i=1:nn_TP_disp
    node_orign_add(i)=coefficient_all_disp*U2_TP_Disp(2*i);%%%%%%%%%%%%%%%%%%%%%%%%%%%%这里是加了一个修正系数，GLUE算法获得的位移场比真实的要大百分之20
end
% node_orign_add=U2_TP_Disp; %% 这里根据GLUE算法求得的位移场求取2D截面下边界各个节点的位移；需要调用：US_disp_TP_Phantom.m文件事先计算
[nodes_TP_corse_add,nodes_TP_corse,nodes_TP_DISP]=Map_disp_TP(node_orign_ID,node_orign_add,Map_TP_ID,nodes_TP_corse,coefficient_map_Disp); %% 将2D截面下边界的位移场映射至3D的底面
save('0715_exp2_nodes_TP_DISP.mat','nodes_TP_DISP')
%% 计算贴片对应的接触力
% Force_contact=FUN_FEM_3D_forward_TP(expID,E_modulus_TP6,nodes_TP_DISP,Map_TP_ID); %% 
Force_contact=FUN_FEM_3D_forward_TP_2(expID,E_modulus_TP6,nodes_TP_DISP,Map_TP_ID); %% 
%% 将贴片底部节点对应的接触力赋值给下面假体
Force_phantom=zeros(3*size(nodes_phantom_corse,1),1);
Force_phantom(3*map_couple(:,1))=Force_contact; %% 将贴片的力赋值给假体上面
FFG_contact=Force_phantom;
save('0715_exp2_FFG_contact.mat','FFG_contact');
% alpha=3.84;
alpha=6.88;
E_modulus=12500/1e6; % 这里杨氏模量单位是N/(mm^2);
% E_modulus=12.5e3;
UUG_3D_all=FUN_FEM_3D_forward_Phantom_force(expID,E_modulus,alpha);
UUG_RegionNode_US=UUG_3D_all(3*RegionNode_US);
UUG_RegionNode_real=-U2_real_Local(2:2:end);
error=UUG_RegionNode_US-UUG_RegionNode_real;
% figure,
% plot(UUG_RegionNode_US,'r');
% hold on 
% plot(UUG_RegionNode_real,'k')
% plot(error,'g')
%% 直接法求取3D的背景杨氏模量值
UUG_RegionNode_real=-coefficient_aphantom_disp*U2_real_Local(2:2:end);
modulus_3D=FUN_3D_modulus_direct(expID,FFG_contact,UUG_RegionNode_real,alpha);
disp(['real modulus of 8% is 12.5Kpa, the calculated Young''s modulus is',num2str(modulus_3D)])
% UUG_3D_all_new=FUN_FEM_3D_forward_Phantom_force(expID,modulus_3D,alpha);
% disp(modulus_3D);
%%
% scatter3(nodes_TP_corse(map_couple(:,2),1),nodes_TP_corse(map_couple(:,2),2),nodes_TP_corse(map_couple(:,2),3))
% axis equal
% scatter3(nodes_phantom_corse(map_couple(:,1),1),nodes_phantom_corse(map_couple(:,1),2),nodes_phantom_corse(map_couple(:,1),3))
% axis equal