function ID_out=mapsetID(nnode,Control_ID,ID_in)

G2L_map=cal_ob_map_base(nnode,Control_ID);

ID_matrix_in=zeros(nnode,1);
ID_matrix_in(ID_in)=1;

ID_matrix_out=G2L_map*ID_matrix_in;
ID_out=find(ID_matrix_out>0);
