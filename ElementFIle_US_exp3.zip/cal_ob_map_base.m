function map_matrix=cal_ob_map_base(nnode,Control_ID)
Cnum=length(Control_ID);
map_matrix=zeros(Cnum,nnode);


for i=1:Cnum
    map_matrix(i,Control_ID(i))=1;
end

