%% 该函数是处理 fileFolder 下面的所有子文件，并且将其存储到folder_path下面的子文件夹folder_path下面
function  FUN_Image_process(fileFolder,folder_path,folder_add)
    dirOutput = dir(fullfile(fileFolder,folder_path));
    fileNames = {dirOutput.name};
%     folder_add='before';
    folder_path2=fullfile(fileFolder,folder_add);
    mkdir(folder_path2);
    filepath_USimage=folder_path2;
    %提取图片并保存
    for i=3:length(fileNames)
        A=fileNames(1,i);
        a=cell2mat(A);
    % 设置文件路径以及文件分辨率
    filepath = fullfile(fileFolder,folder_path,a,'/ultrasound.yuv');
    width = 1280;
    height = 1024;
    % 读取yuv文件
    yuvFileID = fopen(filepath, 'r');
    yuvData = fread(yuvFileID, width * height * 2, 'uint8');
    fclose(yuvFileID);
    j = 1;
    for i =1:4:width * height * 2
        yData(j) = yuvData(i);
        uData(j) = yuvData(i+1);
        uData(j+1) = yuvData(i+1);

        yData(j+1) = yuvData(i+2);
        vData(j) = yuvData(i+3);
        vData(j+1) = yuvData(i+3);
        j=j+2;
    end
    yData = reshape(yData, [width, height]);
    yData = yData';
    %%
    uData = reshape(uData, [width, height]);
    uData = uData';
    %%
    vData = reshape(vData, [width, height]);
    vData = vData';
    %%
    rData = yData + 1.13983 * (vData - 128);
    gData = yData - 0.39465 * (uData - 128) - 0.58060 * (vData - 128);
    bData = yData + 2.03211 * (uData - 128);
    rgbData = cat(3, rData, gData, bData);
    rgbData = uint8(rgbData);
    % 显示rgb图像
    imshow(rgbData);
    %保存bmp格式图片
    imageData = getimage(gcf); 
    croppedFileName0 = [a, 'initial', '.bmp'];
    croppedFilePath = fullfile(filepath_USimage, croppedFileName0);
    imwrite(imageData, croppedFilePath);
    %%
    rect = getrect;%%手动框选。
    disp(rect);
    % 显示原始图像
    figure('Name', '原始图像');
%     rect=[254,171,1025,293];% for the  贴片范围
%     rect=[666,164,206,409];% for the 贴片加假体
%     rect=[600,175,351,526];% for the 假体
    % rect=[594 ,  168  , 356  , 534];
    croppedImage = imcrop(imageData, rect);
    %% 读取原始 BMP 图片并修改图片尺寸
    % 拉伸为指定大小
    resizedImage = imresize(croppedImage, [1700 508]);
    % 显示拉伸后的图片
    imshow(resizedImage);
    % 保存拉伸后的图片为 BMP 文件
    croppedFileName2 = [a, '_resizedtest', '.bmp'];
    croppedFilePath = fullfile(filepath_USimage, croppedFileName2);
    imwrite(resizedImage, croppedFilePath);
    close all;
    end
end