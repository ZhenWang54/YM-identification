% clear;
% clc;
% close all;
tic;
alpha_3D_NEW=Tri_alpha_tool_3D_disp(1,0.1,500)
toc;
